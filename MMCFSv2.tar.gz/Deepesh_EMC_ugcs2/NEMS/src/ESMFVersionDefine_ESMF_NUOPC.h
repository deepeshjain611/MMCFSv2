#if 0
//
// Make this header file available as ESMFVersionDefine.h in order to build
// NEMS against an ESMF installation that contains a reference level NUOPC Layer.
//
#endif

#include "./ESMFConvenienceMacros.h"

