source /home/SSPMRES/deepesh/Deepesh_EMC_ugcs2/NEMS/src/conf/module-setup.sh.inc
module use /home/SSPMRES/deepesh/Deepesh_EMC_ugcs2/NEMS/src/conf
module load modules.nems
