#!/bin/bash

set +x  
#module load NetCDF-cray-sandybridge/3.6.3
#module load NetCDF/4.2/serial                     
module list
set -x

export CFLAGSM="-O3 -xHost"
export LDFLAGSM=

export NCDF="-L$NETCDF/lib -lnetcdf"
echo "NCDF is $NCDF"
#export NCDF=$NETCDF_LDFLAGS_C
export INC="-I$NETCDF/include -I$I_MPI_ROOT"
#export INC="$NETCDF_INCLUDE -I$I_MPI_ROOT"
export CC=cc

echo; make=`basename $PWD`
echo make-ing ${make%.*}
echo

# make the netcdf cfs_mppnccombine executable

make -f Makefile
mv ${make%.*} ../../exec
rm -f *.o *.mod

#make the mpi wrapper

$ftn -traceback -g -o cfs_mpinccombine mpinccombine.f -I$I_MPI_INC                          
mv cfs_mpinccombine ../../exec
rm -f *.o *.mod
