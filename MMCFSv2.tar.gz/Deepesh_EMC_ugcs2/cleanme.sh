#!/bin/sh

rm -Rf MOM6-INSTALL
rm -Rf CICE-INSTALL
rm -Rf GSM-INSTALL
rm -Rf MOM6/exec
rm -Rf MOM6/build
rm -Rf CICE/compile
rm -f CICE/cice
rm -f NEMS/exe/NEMS.x
rm -f ic_utils/mom4to5/genFillNc
rm -f ic_utils/mom4to5/cvtR4p0To5p1

rm -f *.install.md5sum.*
find . -name "*.x" -exec rm {} \;
find . -name "*.o" -exec rm {} \;
find . -name "*.mod" -exec rm {} \;
find . -name "*.a" -exec rm {} \;
find ./GSM -name "*.f90" -exec rm {} \;
