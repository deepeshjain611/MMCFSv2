rm -rf extra
mkdir -p extra

newname="$(echo "$PWD" | cut -c72-)"
echo $newname


cp cfsv2_analysis_HIC_*.tar extra/
cd extra
tar -xvf cfsv2_analysis_HIC_*.tar 




mv cdas1.t12z.sfcanl ../sfcanl.gdas.$newname
mv cdas1.t12z.sanl ../siganl.gdas.$newname


#for name in ocnanl.gdas.*
#do
#    newname="$(echo "$name" | cut -c24-)"
#    mv "$name" "$newname"
#done


rm cfsv2_analysis_HIC_*12.tar
tar -cvf cdas1.t12z.ocnanl.tar *
mv cdas1.t12z.ocnanl.tar ../
rm *

