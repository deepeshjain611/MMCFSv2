#!/bin/bash 
set -x

export machine=wcoss
export FC=ftn


NETCDF_LIB  = -L/opt/cray/pe/netcdf/4.4.1.1.3/INTEL/16.0/lib -lnetcdff -lnetcdf /opt/cray/pe/hdf5/1.10.0.3/INTEL/16.0/lib/libhdf5.a /home/apps/zlib/1.2.6/intel/17.0.5/lib/libz.a
NETCDF_INCLUDE = -I/opt/cray/pe/netcdf/4.4.1.1.3/INTEL/16.0/include

#W3_LIB      = ${W3NCO_LIBd} ${W3EMC_LIBd}
#BACIO_LIB   = ${BACIO_LIB4}
#SP_LIB      = ${SP_LIBd}

W3EMC_LIB4  = /home/apps/NWPROD/global_shared.v14.1.3/libs/w3nco/v2.0.6/libw3nco_v2.0.6_d.a /home/apps/NWPROD/global_shared.v14.1.3/libs/w3emc/v2.2.0/w3emc_v2.2.0_d/libw3emc_v2.2.0_d.a
W3NCO_LIB4  = /home/apps/NWPROD/global_shared.v14.1.3/libs/w3nco/v2.0.6/libw3nco_v2.0.6_d.a /home/apps/NWPROD/global_shared.v14.1.3/libs/w3emc/v2.2.0/w3emc_v2.2.0_d/libw3emc_v2.2.0_d.a   
SP_LIB4     = /home/apps/NWPROD/global_shared.v14.1.3/libs/sp/v2.0.2/libsp_v2.0.2_4.a
SIGIO_LIB   = /home/apps/NWPROD/global_shared.v14.1.3/libs/sigio/v2.0.1/libsigio_v2.0.1_4.a
SFCIO_LIB   = /home/apps/NWPROD/global_shared.v14.1.3/libs/sfcio/v1.0.0/libsfcio_v1.0.0_4.a
BACIO_LIB4  = /home/apps/NWPROD/global_shared.v14.1.3/libs/bacio/v2.0.2/lib/libbacio_4.a
SYS_LIB     =
NEMSIO_INC=/home/apps/NWPROD/global_shared.v14.1.3/libs/nemsio/v2.2.2/incmod
NEMSIO_LIB=/home/apps/NWPROD/global_shared.v14.1.3/libs/nemsio/v2.2.2/libnemsio_v2.2.2.a
ESMF_MOD=/home/SSPMRES/deepesh/esmf/esmf/mod/modO/Unicos.intel.64.mpi.default


#POSTDIR     = /global/save/Shrinivas.Moorthi/nceppost_moorthi_redmem_merge/sorc/ncep_post.fd
POSTDIR     = /home/apps/NWPROD/global_shared.v14.1.3/sorc/ncep_post.fd
POSTMOD     = ${POSTDIR}/incmod/post_4
POST_INC    = -I${POSTDIR}/incmod/post_4
POST_LIB    = -L${POSTDIR} -lnceppost
#W3_POST_LIB = ${W3NCO_LIB4} ${W3EMC_LIB4}
W3_POST_LIB = /home/apps/NWPROD/global_shared.v14.1.3/libs/w3nco/v2.0.6/libw3nco_v2.0.6_4.a /home/apps/NWPROD/global_shared.v14.1.3/libs/w3emc/v2.2.0/w3emc_v2.2.0_4/lib/libw3emc_v2.2.0_4.a
#G2_LIB      = ${G2TMPL_LIB} ${G2_LIB4} ${JASPER_LIB} ${PNG_LIB} ${Z_LIB}
G2_LIB      = /home/apps/NWPROD/global_shared.v14.1.3/libs/g2tmpl/v1.4.0/intel/libg2tmpl.a /home/apps/NWPROD/global_shared.v14.1.3/libs/g2/v2.5.0/intel/libg2_4.a /home/apps/jasper/1.900.1/intel/17.0.5/with-fpic/lib/libjasper.a /home/apps/libpng/1.2.44/intel/17.0.5/lib/libpng.a /home/apps/zlib/1.2.6/intel/17.0.5/lib/libz.a

#XML_LIB     = ${XMLPARSE_LIB}
XML_LIB     = /home/apps/NWPROD/global_shared.v14.1.3/libs/xmlparse/libxmlparse.a



export FFLAGSM="-O3 -real-size 32 -convert big_endian -qopenmp -traceback"
export LDFLAGSM=
 
export LIBSM="$BACIO_LIB4 $W3EMC_LIB4 $W3NCO_LIB4 $SP_LIB4"

echo; make=`basename $PWD`
echo make-ing ${make%.*}
echo

make -f Makefile
mv ${make%.*} ../../exec
rm -f *.o *.mod

