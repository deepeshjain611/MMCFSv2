#!/bin/bash
set -euax

# Adapted from: Xingren Wu
# 2016-09-02
# This scripts is for CFS/UGCS ocean post

# Christopher Melhauser
# 2017-09-11
# This script is for UGCS CICE5/MOM5 ocean and ice post

# Xingren Wu
# 2017-10-23
# Update and bug/fix

#module purge
#module load ics/12.1
#module load prod_util/v1.0.7
#module load NetCDF/4.2/serial

#export execdir=${execdir:-/climate/save/emc.climpara/Xingren/regrid/iceocnpost/exec}
#export executable=${executable:-$execdir/reg2grb2.x}

#export CDATE=2015040106
#export IDATE=2015040100
#export icefile=/climate/save/emc.climpara/Xingren/regrid/out/icer2015040106.01.2015040100_0p5x0p5_CICE.nc
#export ocnfile=/climate/save/emc.climpara/Xingren/regrid/out/ocnr2015040106.01.2015040100_0p5x0p5_MOM6.nc
#export outfile=/climate/save/emc.climpara/Xingren/regrid/out/ocnh2015040106.01.2015040100.grb2

export icefile=icer${CDATE}.${ENSMEM}.${IDATE}_0p5x0p5_CICE.nc
export ocnfile=ocnr${CDATE}.${ENSMEM}.${IDATE}_0p5x0p5_MOM6.nc
export outfile=ocnr${CDATE}.${ENSMEM}.${IDATE}_0p5x0p5_MOM6.grb2

export mfcstcpl=${mfcstcpl:-1}
export IGEN_OCNP=${IGEN_OCNP:-197}

# PT This is the forecast date
export year=`echo $CDATE | cut -c1-4`
export month=`echo $CDATE | cut -c5-6`
export day=`echo $CDATE | cut -c7-8`
export hour=`echo $CDATE | cut -c9-10`

# PT This is the initialization date
export syear=`echo $IDATE | cut -c1-4`
export smonth=`echo $IDATE | cut -c5-6`
export sday=`echo $IDATE | cut -c7-8`
export shour=`echo $IDATE | cut -c9-10`

# PT Need to get this from above - could be 6 or 1 hour
export hh_inc_ocn=6

export fh=$($NHOUR $CDATE $IDATE)

# Currently set for 0p5 lat-lon
export im=720
export jm=361
export km=40
export imo=720
export jmo=361


export flats=-90.
export flatn=90.
export flonw=0.0
export flone=359.5

ln -sf $OCNFIXDIR/mask.0p5x0p5.grb2 ./iceocnpost.g2

$executable > reg2grb2.$CDATE.$IDATE.out
