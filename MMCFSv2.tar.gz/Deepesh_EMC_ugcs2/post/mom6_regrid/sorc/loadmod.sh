 module load PrgEnv-intel
 module unload intel
 module unload craype-haswell
 module load craype-sandybridge
 module load intel/16.3.210
 module use /usrx/local/nceplibs/modulefiles
 module load w3nco-intel/2.0.6
 module load bacio-intel/2.0.2
 module load sp-intel/2.0.2
 module load ip-intel/3.0.0
 module load landsfcutil-intel/2.1.0
 module load cfp-intel-sandybridge
 module list
