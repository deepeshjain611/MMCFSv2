#!/bin/sh
set -x
mac1=$(echo $HOSTNAME | cut -c1-1)
mac3=$(echo $HOSTNAME | cut -c1-3)

# WCOSS
if [ $mac3 != tfe ] && [ $mac1 = g -o $mac1 = t ] ; then
 export machine=wcoss
 export FC=ifort
 export FC90=ifort
 export CPP=fpp

 export FFLAGSM="-O3 -free -convert big_endian -traceback -openmp"
 export FFLAGSM2="-O3 -free -r8"
 export LDFLAGSM=
 
 export LIBDIR=/nwprod/lib

 #export NCDF="-L/usrx/local/NetCDF/3.6.3/lib -lnetcdf"
 #export INC=/usrx/local/NetCDF/3.6.3/include
 export NCDF="-L/usrx/local/NetCDF/4.2/serial/lib -lnetcdff"
 export INC=/usrx/local/NetCDF/4.2/serial/include


 export LIBSM="-L${LIBDIR} -lw3nco_4 -lbacio_4 -lsp_4 -lip_4 -llandsfcutil_4 -llandsfcutil_4"

# grib2.v2.0.7
 export LIB2="-L/u/Wesley.Ebisuzaki/home/grib2.v2.0.7/lib -lwgrib2 -lwgrib2_api"
 export MOD2="-I/u/Wesley.Ebisuzaki/home/grib2.v2.0.7/lib"

# WCOSS-Cray 
elif [ $mac3 = elo -o $mac3 = llo ]; then

 export machine=wcoss.cray
 export FC=ftn
 export FC90=ftn
 export CPP=fpp

# module load PrgEnv-intel
# module unload intel
# module unload craype-haswell
# module load craype-sandybridge
# module load intel/16.3.210
# module use /usrx/local/nceplibs/modulefiles
# module load w3nco-intel/2.0.6
# module load bacio-intel/2.0.2
# module load sp-intel/2.0.2
# module load ip-intel/3.0.0
# module load landsfcutil-intel/2.1.0
# #module load cfp-intel-sandybridge
 export LIBDIR=/home/SSPMRES/deepesh/Deepesh_EMC_ugcs2/post/iceocnpost/sorc/libdir
 source /home/SSPMRES/deepesh/Deepesh_EMC_ugcs2/post/iceocnpost/sorc/setup.xc.intel

 module list

 export FFLAGSM="-O3 -free -convert big_endian -g -traceback -qopenmp -xCORE-AVX2 "
 export FFLAGSM2="-O3 -free -r8 -g -traceback -xCORE-AVX2"

 export LDFLAGSM=

# export LIBDIR=""

 # NetCDF-intel-sandybridge/3.6.3

 export NCDF="-L/opt/cray/pe/netcdf/4.4.1.1.3/INTEL/16.0/lib -lnetcdf"
 export INC=/opt/cray/pe/netcdf/4.4.1.1.3/INTEL/16.0/include


# export LIBSM="-L${LIBDIR} -lw3nco_4 -lbacio_4 -lsp_4 -lip_4 -llandsfcutil_4 -llandsfcutil_4"
 export LIBSM="-L${LIBDIR} -lw3nco_4 -lbacio_4 -lsp_4 -lip_4 -llandsfcutil_4 -llandsfcutil_4"

# export LIB2="-L/u/Wesley.Ebisuzaki/home/grib2_v2.0.7b2/lib -lwgrib2 -lwgrib2_api"
# export MOD2="-I/u/Wesley.Ebisuzaki/home/grib2_v2.0.7b2/lib"
 export LIB2="-L/home/apps/wgrib2/4.0/lib -lwgrib2 -lwgrib2_api"
 export MOD2="-I/home/apps/wgrib2/4.0/include"


export LIBSM="-L${LIBDIR} -lw3nco_4 -lbacio_4 -lsp_4 -lip_4 -llandsfcutil_4"
# export LIBSM="${W3NCO_LIB4} ${BACIO_LIB4} ${SP_LIB4} ${IP_LIB4} ${LANDSFCUTIL_LIB4}"

# export LIB2="-L/u/Wesley.Ebisuzaki/home/grib2_v2.0.7b2/lib -lwgrib2 -lwgrib2_api"
# export MOD2="-I/u/Wesley.Ebisuzaki/home/grib2_v2.0.7b2/lib"
 export LIB2="-L/home/apps/wgrib2/4.0/lib -lwgrib2 -lwgrib2_api"
 export MOD2="-I/home/apps/wgrib2/4.0/include"

# Theia 
elif [ $mac3 = tfe ]; then
 export machine=theia
 export FC=ifort
 export FC90=ifort
 export CPP=fpp
 export LIBDIR=/home/SSPMRES/deepesh/Deepesh_EMC_ugcs2/post/iceocnpost/sorc/libdir

 # You have to load this before running makefile.sh
 # module load intel/14.0.2

 export FFLAGSM="-O3 -free -convert big_endian -traceback -openmp"
 export FFLAGSM2="-O3 -free -r8"
 export LDFLAGSM=

 export LIBDIR=/scratch3/NCEPDEV/nwprod/NWPROD.WCOSS/lib

 export NCDF="-L/apps/netcdf/3.6.3-intel/lib -lnetcdf"
 export INC=/apps/netcdf/3.6.3-intel/include

 export LIBSM="-L${LIBDIR} -lw3nco_4 -lbacio_4 -lsp_4 -lip_4 -llandsfcutil_4 -llandsfcutil_4"

 # /scratch4/NCEPDEV/cpc/noscrub/Wesley.Ebisuzaki/grib2/lib
 export LIB2="-L/home/apps/wgrib2/INTEL/16/3.0.0/lib -lwgrib2 -lwgrib2_api"
 export MOD2="-I/home/apps/wgrib2/INTEL/16/3.0.0/include"

else
 export LIB2="-L/home/apps/wgrib2/INTEL/16/3.0.0/lib -lwgrib2 -lwgrib2_api"
 export MOD2="-I/home/apps/wgrib2/INTEL/16/3.0.0/include"
 machine=wcoss
 export FC=ftn
 export FC90=ftn
 export FFLAGSM="-O3 -free -convert big_endian -traceback -openmp"
 export FFLAGSM="-O3 -free -r8"

 export LIBFLAGSM=
 
 export LIBDIR=/home/SSPMRES/deepesh/EMC_ugcsN/commonlibs/lib

 export NCDF=/opt/cray/pe/netcdf/4.4.1.1.3/INTEL/16.0/lib/libnetcdf.a
 export INC=/opt/cray/pe/netcdf/4.4.1.1.3/INTEL/16.0/include

 export LIBSM="-L${LIBDIR} -lbacio_4 -lw3_4 -lsp_4 -lip_4 -llandsfcutil_4 -llandsfcutil_4"
fi

errchk=0
mkdir ../exec
make clean
make -f Makefile
errchk=$?
cp reg2grb2.x ../exec
exit $errchk
