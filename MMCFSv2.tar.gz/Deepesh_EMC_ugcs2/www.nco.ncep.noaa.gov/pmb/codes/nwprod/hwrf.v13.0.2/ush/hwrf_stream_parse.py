#! /usr/bin/env python

##@namespace ush.hwrf_stream_parse
# This is a wrapper around produtil.atparse.AtParser, a simple preparser
#
# This script reads in a file with special control symbols, performs
# string replacements, file insertions, etc. and outputs the result to
# stdout.
# @code{.sh}
#  hwrf_stream_parse.py [--] file1 [file2 [file3 [...] ]]
# @endcode
#
# The special filename "-" requests reading of stdin.  The "--" option
# requests termination of option parsing.  Hence, to read the actual
# file "-", you would do "hwrf_stream_parse.py -- -" whereas to read
# stdin, you do "hwrf_stream_parse.py -"

import sys, logging
from produtil.atparse import ATParser

def main():       
    p=ATParser(logger=logging.getLogger('streamparse'))
    nodash=False
    logging.basicConfig()
    for file in sys.argv[1:]:
        if not nodash:
            if file=='--':
                nodash=True
                continue
            elif file=='-':
                p.parse_stream(sys.stdin,'(stdin)')
                continue
        p.parse_file(file)

if __name__=='__main__': main()
