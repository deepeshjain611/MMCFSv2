#!/bin/sh
set -x

GRID_TYPE=${1:?"GRID_TYPE must be provided as the furst input parameter"}
fhr=${2:?"fhr must be given as the second input parameter"}
GBFILE=${COMIN}/${storm_id}.${PDY}${cyc}.hwrfprs.${GRID_TYPE}.f${fhr}.grb2

case $GRID_TYPE in
  global.0p25)      #hwrf/hwrfc_YYYYMMDDHHfFFF_*
    cd ${DATA:?}/${RUN:?}/
    GBSUBSETFILE=${storm_id}.${PDY}${cyc}.hwrfprs_subset.${GRID_TYPE}.f${fhr}.grb2
    $WGRIB2 -s $GBFILE | grep -F -f $PARMhwrf/gempak_global_subset.txt | $WGRIB2 -i -grib_out $GBSUBSETFILE $GBFILE
    GBFILE=$GBSUBSETFILE
    GDOUTF=${RUN}c_${PDY:?}${cyc:?}f${fhr:?}_${storm_id:?}
    COMOUTF=${RUN}c_${PDY}${cyc}f${fhr}_${storm_id};;
  core.0p015)        #hwrf/hwrfn_YYYYMMDDHHfFFF_*
    cd ${DATA:?}/${RUN:?}/
    GDOUTF=${RUN}n_${PDY:?}${cyc:?}f${fhr:?}_${storm_id:?}
    COMOUTF=${RUN}n_${PDY}${cyc}f${fhr}_${storm_id};;
  synoptic.0p125)   #hwrfp/hwrfc_YYYYMMDDHHfFFF_*
    cd ${DATA:?}/${RUN:?}p/
    GDOUTF=${RUN}c_${PDY:?}${cyc:?}f${fhr:?}_${storm_id:?}
    COMOUTF=${RUN}p_${PDY}${cyc}f${fhr}_${storm_id};;
  *)
    err_exit "$GRID_TYPE not recognized";;
esac

export pgm=nagrib2; startmsg

${GEMEXE:?}/nagrib2 << EOF
 GBFILE   = $GBFILE
 GDOUTF   = $GDOUTF
 PROJ     = 
 GRDAREA  = 
 KXKY     = 
 MAXGRD   = 1000
 CPYFIL   = GDS
 GAREA    = DSET
 OUTPUT   = T
 G2TBLS   = 
 G2DIAG   = 
 OVERWR   = NO
 PDSEXT   = NO
l
r
EOF
export err=$?; err_chk

############################################################
# Gempak does not always have a non-zero return code when it
# cannot produce the desired grid. Check for this case here.
############################################################
ls -l $GDOUTF
export err=$?; err_chk

touch $GDOUTF.done

if [ "$pgm" = "nagrib2" ]; then
  $GEMEXE/gpend
fi

cpreq $GDOUTF $COMOUT/$COMOUTF

if [ "${SENDDBN^^}" = "YES" ]; then
  $DBNROOT/bin/dbn_alert MODEL HWRF_GEMPAK $job $COMOUT/$COMOUTF
fi

