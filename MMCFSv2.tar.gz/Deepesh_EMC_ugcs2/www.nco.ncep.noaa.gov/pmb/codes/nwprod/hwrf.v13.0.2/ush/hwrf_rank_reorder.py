#! /usr/bin/env python

import numpy, sys, os, getopt, StringIO, re, math
from numpy import ndarray

(ni,nj,mi,mj) = [ int(i) for i in sys.argv[1:5] ]
ranks=ndarray(ni*nj*mi*mj)
ranks[:]=xrange(0,ni*nj*mi*mj)
ranks=ranks.reshape([nj,mj,ni,mi])
rankorder=[ list() for n in xrange(ni*nj) ]

print '# Rank reordering for %dx%d grid of compute nodes, %dx%d per node'%(
    ni,nj,mi,mj)
print 'wrf_%dx%d_%dx%d = ['%(ni,nj,mi,mj)

fmt='%%%dd'%int(math.ceil(math.log(ni*nj*mi*mj,9.9999)))

for inj in xrange(nj):
    for imj in xrange(mj):
        for ini in xrange(ni):
            for imi in xrange(mi):
                inode=inj*ni+ini
                assert(inode<ni*nj)
                ri=rankorder[inode]
                (rankorder[inode]).append(ranks[inj,imj,ini,imi])
                if not  (len(rankorder[inode])<=mi*mj):
                    raise Exception('BAD: len(rankorder[%d])=%d>%d*%d=%d'%(
                        inode,len(rankorder[inode]),mi,mj,mi*mj))

for ro in rankorder:
    print('['+','.join([ fmt%i for i in ro ])+'],')

print ']'
