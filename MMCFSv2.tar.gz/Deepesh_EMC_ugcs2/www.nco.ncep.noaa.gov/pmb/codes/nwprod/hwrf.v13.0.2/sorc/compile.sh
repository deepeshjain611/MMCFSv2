#! /bin/sh

set -u -e -x

SORChwrf=$(pwd)

echo "compiling libs"
cd ../libs
./install_lib.scr
echo "libs compile done"
cd $SORChwrf

echo "compiling hwrf_v4.0.0"
cd hwrf_v4.0.0.fd
###./install_nmm.scr > ../build_hwrf.v4.0.0.log 2>&1
./install_nmm.scr
echo "hwrf_v4.0.0 compile done"
cd $SORChwrf

echo "compiling hwrf_gsi"
cd hwrf_gsi.fd/src
cd ..
./install_gsi.scr
echo "hwrf_gsi compile done"
cd $SORChwrf

echo "compiling hwrf_init"
cd hwrf_init.fd
./install_init.scr
echo "hwrf_init compile done"
cd $SORChwrf

echo "compiling hwrf_ncep_coupler"
cd hwrf_ncep-coupler.fd
./install_coupler.scr
echo "hwrf_ncep_coupler compile done"
cd $SORChwrf

echo "compiling hwrf_vortextracker"
cd hwrf-vortextracker.fd
./install_vortextracker.scr
echo "hwrf_vortextracker compile done"
cd $SORChwrf

echo "compiling hwrf_pomtc"
cd hwrf_pomtc.fd
./install_pomtc.scr
echo "hwrf_pomtc compile done"
cd $SORChwrf

echo "compiling hwrf_tools"
cd hwrf_tools.fd
./install_tool.scr
echo "hwrf_tools compile done"
cd $SORChwrf

echo "compiling hwrf_ww3"
cd hwrf_ww3.fd
./install_ww3.scr
echo "hwrf_ww3 compile done"
cd $SORChwrf

echo "compiling hwrf wps"
cd hwrf_wps.fd
./install_wps.scr
echo "hwrf_wps compile done"
cd $SORChwrf

echo "compiling hwrf hycom"
cd hwrf_hycom.fd
./install_hycom.scr
echo "hwrf_hycom compile done"
cd $SORChwrf

echo "compiling hwrf_post"
cd hwrf_post.fd/comupp
./install_post.scr
echo "hwrf_post compile done"
cd $SORChwrf

