#! /bin/sh

set -x

# copy executables from hwrf_v3.8.1.fd:
cp hwrf_v4.0.0.fd/hwrf_wrf                        ../exec/hwrf_wrf
cp hwrf_v4.0.0.fd/hwrf_real_nmm                   ../exec/hwrf_real_nmm

# copy executables from hwrf_gsi.fd:
cp hwrf_gsi.fd/exec/global_gsi.x                   ../exec/hwrf_gsi
cp hwrf_gsi.fd/exec/wrf_enkf.x                     ../exec/hwrf_enkf

# copy executables from hwrf_tools.fd:
cp hwrf_tools.fd/exec/hwrf_da_update_analysis.exe          ../exec/hwrf_da_update_analysis
cp hwrf_tools.fd/exec/hwrf_tempdrop.exe                    ../exec/hwrf_tempdrop
cp hwrf_tools.fd/exec/hwrf_obstobufr.exe                   ../exec/hwrf_obstobufr
cp hwrf_tools.fd/exec/hwrf_afos.exe                        ../exec/hwrf_afos
cp hwrf_tools.fd/exec/hwrf_atcf_to_stats.exe               ../exec/hwrf_atcf_to_stats
cp hwrf_tools.fd/exec/hwrf_aux_rw.exe                      ../exec/hwrf_aux_rw
cp hwrf_tools.fd/exec/hwrf_bin_io.exe                      ../exec/hwrf_bin_io
cp hwrf_tools.fd/exec/hwrf_combinetrack.exe                ../exec/hwrf_combinetrack
#mv hwrf_tools.fd/hwrf_data_remv                   ../exec/hwrf_data_remv
#mv hwrf_tools.fd/exec/hwrf_gettrk.exe                      ../exec/hwrf_gettrk
cp hwrf_tools.fd/exec/hwrf_gridgenfine.exe                 ../exec/hwrf_gridgenfine
cp hwrf_tools.fd/exec/hwrf_prep.exe                        ../exec/hwrf_prep
cp hwrf_tools.fd/exec/hwrf_read_indi_write_all.exe         ../exec/hwrf_read_indi_write_all
cp hwrf_tools.fd/exec/hwrf_supvit.exe                      ../exec/hwrf_supvit
cp hwrf_tools.fd/exec/hwrf_swath.exe                       ../exec/hwrf_swath
cp hwrf_tools.fd/exec/hwrf_wrfout_newtime.exe              ../exec/hwrf_wrfout_newtime
cp hwrf_tools.fd/exec/hwrf_htcfstats.exe                   ../exec/hwrf_htcfstats
cp hwrf_tools.fd/exec/hwrf_bdy_update.exe                  ../exec/hwrf_bdy_update
cp hwrf_tools.fd/exec/hwrf_binary_grads.exe                ../exec/hwrf_binary_grads
cp hwrf_tools.fd/exec/hwrf_rem_prepbufr_typ_in_circle.exe  ../exec/hwrf_rem_prepbufr_typ_in_circle
cp hwrf_tools.fd/exec/hwrf_change_prepbufr_qm_in_circle.exe ../exec/hwrf_change_prepbufr_qm_in_circle
cp hwrf_tools.fd/exec/hwrf_change_prepbufr_qm_typ.exe       ../exec/hwrf_change_prepbufr_qm_typ
#mv hwrf_tools.fd/hwrf_data_flag                   ../exec/hwrf_data_flag
cp hwrf_tools.fd/exec/hwrf_netcdf_grads.exe                ../exec/hwrf_netcdf_grads
cp hwrf_tools.fd/exec/hwrf_readtdrstmid.exe                ../exec/hwrf_readtdrstmid
cp hwrf_tools.fd/exec/hwrf_readtdrtime.exe                 ../exec/hwrf_readtdrtime
cp hwrf_tools.fd/exec/hwrf_readtdrtrigger.exe              ../exec/hwrf_readtdrtrigger
cp hwrf_tools.fd/exec/hwrf_nhc_products.exe                ../exec/hwrf_nhc_products
cp hwrf_tools.fd/exec/hwrf_metgrid_levels.exe              ../exec/hwrf_metgrid_levels
cp hwrf_tools.fd/exec/hwrf_blend_gsi.exe                   ../exec/hwrf_blend_gsi
#rmcp hwrf_tools.fd/exec/hwrf_atcf_prob.exe                   ../exec/hwrf_atcf_prob
#rmcp hwrf_tools.fd/exec/hwrf_ens_prob.exe                    ../exec/hwrf_ens_prob
cp hwrf_tools.fd/exec/copygb.exe                           ../exec/hwrf_egrid2latlon
cp hwrf_tools.fd/exec/satgrib2.exe                         ../exec/hwrf_satgrib2
cp hwrf_tools.fd/exec/cnvgrib.exe                          ../exec/hwrf_cnvgrib
cp hwrf_tools.fd/exec/wgrib2.exe                           ../exec/hwrf_wgrib2
cp hwrf_tools.fd/exec/hwrf_final_merge.exe                 ../exec/hwrf_final_merge
cp hwrf_tools.fd/exec/hwrf_regrid_merge.exe                ../exec/hwrf_regrid_merge
cp hwrf_tools.fd/exec/hwrf_readtdrtrack.exe                ../exec/hwrf_readtdrtrack
cp hwrf_tools.fd/exec/hwrf_wrfbdy_tinterp.exe              ../exec/hwrf_wrfbdy_tinterp
cp hwrf_tools.fd/exec/hwrf_ensemble.exe                    ../exec/hwrf_ensemble
cp hwrf_tools.fd/exec/hwrf_interpolate.exe                 ../exec/hwrf_interpolate
cp hwrf_tools.fd/exec/mpiserial.exe                        ../exec/mpiserial
# - get from mpiserial/2.0.0 module mv hwrf_tools.fd/exec/mpiserial.exe                        ../exec/mpiserial


# copy executables from hwrf_init.fd:
cp hwrf_init.fd/exec/hwrf_anl_bogus_10m.exe                ../exec/hwrf_anl_bogus_10m
cp hwrf_init.fd/exec/hwrf_anl_cs_10m.exe                   ../exec/hwrf_anl_cs_10m
cp hwrf_init.fd/exec/hwrf_anl_4x_step2.exe                 ../exec/hwrf_anl_4x_step2
cp hwrf_init.fd/exec/hwrf_create_trak_fnl.exe              ../exec/hwrf_create_trak_fnl
cp hwrf_init.fd/exec/hwrf_create_trak_guess.exe            ../exec/hwrf_create_trak_guess
cp hwrf_init.fd/exec/hwrf_merge_nest_4x_step12_3n.exe      ../exec/hwrf_merge_nest_4x_step12_3n
cp hwrf_init.fd/exec/hwrf_merge_nest_4x_step12_enkf.exe    ../exec/hwrf_merge_nest_4x_step12_enkf
cp hwrf_init.fd/exec/hwrf_pert_ct1.exe                     ../exec/hwrf_pert_ct1
cp hwrf_init.fd/exec/hwrf_swcorner_dynamic.exe             ../exec/hwrf_swcorner_dynamic
cp hwrf_init.fd/exec/hwrf_split1.exe                       ../exec/hwrf_split1
cp hwrf_init.fd/exec/hwrf_inter_2to1.exe                   ../exec/hwrf_inter_2to1
cp hwrf_init.fd/exec/hwrf_inter_2to2.exe                   ../exec/hwrf_inter_2to2
cp hwrf_init.fd/exec/hwrf_inter_2to6.exe                   ../exec/hwrf_inter_2to6
cp hwrf_init.fd/exec/hwrf_inter_4to2.exe                   ../exec/hwrf_inter_4to2
cp hwrf_init.fd/exec/hwrf_inter_4to6.exe                   ../exec/hwrf_inter_4to6

# copy executables from hwrf-vortextracker.fd:
cp hwrf-vortextracker.fd/trk_exec/hwrf_gettrk.exe              ../exec/hwrf_unified_tracker
cp hwrf-vortextracker.fd/trk_exec/hwrf_tave.exe                ../exec/hwrf_tave
cp hwrf-vortextracker.fd/trk_exec/hwrf_vint.exe                ../exec/hwrf_vint

# copy executables from hwrf_ncep-coupler.fd:
cp hwrf_ncep-coupler.fd/cpl_exec/hwrf_wm3c.exe    ../exec/hwrf_wm3c

# MPIPOM-TC diagnostic ocean initialization
cp hwrf_pomtc.fd/ocean_exec/hycom2raw.xc                            ../exec/hwrf_pom_hycom2raw
cp hwrf_pomtc.fd/ocean_exec/archv2data3z.xc                         ../exec/hwrf_pom_archv2data3z
cp hwrf_pomtc.fd/ocean_exec/pomprep_fbtr.xc                         ../exec/hwrf_ocean_pomprep_fb
cp hwrf_pomtc.fd/ocean_exec/pomprep_idel.xc                         ../exec/hwrf_ocean_pomprep_id
cp hwrf_pomtc.fd/ocean_exec/pomprep_gdm3.xc                         ../exec/hwrf_ocean_pomprep_g3
cp hwrf_pomtc.fd/ocean_exec/pomprep_ncda.xc                         ../exec/hwrf_ocean_pomprep_na
cp hwrf_pomtc.fd/ocean_exec/pomprep_hycu.xc                         ../exec/hwrf_ocean_pomprep_hy
cp hwrf_pomtc.fd/ocean_exec/pomprep_rtof.xc                         ../exec/hwrf_ocean_pomprep_rt
cp hwrf_pomtc.fd/ocean_exec/transatl06prep.xc                       ../exec/hwrf_ocean_transatl06prep
cp hwrf_pomtc.fd/ocean_exec/gfdl_date2day.exe                       ../exec/hwrf_date2day
cp hwrf_pomtc.fd/ocean_exec/gfdl_day2date.exe                       ../exec/hwrf_day2date
cp hwrf_pomtc.fd/ocean_exec/gfdl_getsst.exe                         ../exec/hwrf_getsst
cp hwrf_pomtc.fd/ocean_exec/gfdl_sharp_mcs_rf_l2m_rmy5.exe          ../exec/hwrf_sharp_mcs_rf_l2m_rmy5

# MPIPOM-TC prognostic ocean initialization and coupled forecast
cp hwrf_pomtc.fd/ocean_exec/hwrf_ocean_init.exe                     ../exec/hwrf_ocean_init
cp hwrf_pomtc.fd/ocean_exec/hwrf_ocean_fcst.exe                     ../exec/hwrf_ocean_fcst

# MPIPOM-TC diagnostic post processing
cp hwrf_pomtc.fd/ocean_exec/readsstuvhflux.exe                      ../exec/readsstuvhflux

# copy executables from hwrf_wps.fd:
cp hwrf_wps.fd/hwrf_metgrid                       ../exec/hwrf_metgrid 
cp hwrf_wps.fd/hwrf_geogrid                       ../exec/hwrf_geogrid
cp hwrf_wps.fd/hwrf_ungrib                        ../exec/hwrf_ungrib

# copy exectable from hwrf_post.fd:
cp hwrf_post.fd/comupp/bin/unipost.exe                       ../exec/hwrf_post

# copy exectable from hwrf_init.fd/hwrf_diffwrf_3dvar.fd:
cp hwrf_init.fd/exec/diffwrf_3dvar.exe ../exec/hwrf_diffwrf_3dvar

# copy executable from ww3
cp hwrf_ww3.fd/exec/hwrf_ww3_shel             ../exec/hwrf_ww3_shel
cp hwrf_ww3.fd/exec/hwrf_ww3_grid             ../exec/hwrf_ww3_grid
cp hwrf_ww3.fd/exec/hwrf_ww3_prep             ../exec/hwrf_ww3_prep
cp hwrf_ww3.fd/exec/hwrf_ww3_strt             ../exec/hwrf_ww3_strt
cp hwrf_ww3.fd/exec/hwrf_ww3_outf             ../exec/hwrf_ww3_outf
cp hwrf_ww3.fd/exec/hwrf_ww3_outp             ../exec/hwrf_ww3_outp
cp hwrf_ww3.fd/exec/hwrf_ww3_grib             ../exec/hwrf_ww3_grib
cp hwrf_ww3.fd/exec/hwrf_ww3_ounf             ../exec/hwrf_ww3_ounf
cp hwrf_ww3.fd/exec/hwrf_ww3_ounp             ../exec/hwrf_ww3_ounp
cp hwrf_ww3.fd/exec/hwrf_ww3_prnc             ../exec/hwrf_ww3_prnc
cp hwrf_ww3.fd/exec/hwrf_ww3_bound            ../exec/hwrf_ww3_bound
cp hwrf_ww3.fd/exec/hwrf_ww3_gint             ../exec/hwrf_ww3_gint

# copy executable form hycom
cp hwrf_hycom.fd/exec/hwrf_get_rtofs                  ../exec/hwrf_get_rtofs
cp hwrf_hycom.fd/exec/hwrf_archv2restart              ../exec/hwrf_archv2restart
cp hwrf_hycom.fd/exec/hwrf_gfs2ofs2                   ../exec/hwrf_gfs2ofs2
cp hwrf_hycom.fd/exec/hwrf_ofs_correct_wind           ../exec/hwrf_ofs_correct_wind
#cp hwrf_hycom.fd/exec/hwrf_ofs_edit_restart           ../exec/hwrf_ofs_edit_restart
cp hwrf_hycom.fd/exec/hwrf_ofs_fwind                  ../exec/hwrf_ofs_fwind
cp hwrf_hycom.fd/exec/hwrf_ofs_wind2hycom             ../exec/hwrf_ofs_wind2hycom
cp hwrf_hycom.fd/exec/hwrf_rtofs_restart2restart      ../exec/hwrf_rtofs_restart2restart
cp hwrf_hycom.fd/exec/hwrf_select_domain              ../exec/hwrf_select_domain
cp hwrf_hycom.fd/exec/hwrf_rtofs_isubregion           ../exec/hwrf_rtofs_isubregion
cp hwrf_hycom.fd/exec/hwrf_rtofs_subregion            ../exec/hwrf_rtofs_subregion
cp hwrf_hycom.fd/exec/hwrf_ofs_timeinterp_forcing     ../exec/hwrf_ofs_timeinterp_forcing
cp hwrf_hycom.fd/exec/hwrf_rtofs_edit_gfsfrctime      ../exec/hwrf_rtofs_edit_gfsfrctime
cp hwrf_hycom.fd/exec/ofs_correct_forcing             ../exec/ofs_correct_forcing
cp hwrf_hycom.fd/exec/ofs_getdata_river               ../exec/ofs_getdata_river
cp hwrf_hycom.fd/exec/ofs_getkpds                     ../exec/ofs_getkpds
cp hwrf_hycom.fd/exec/ofs_qc_river                    ../exec/ofs_qc_river
cp hwrf_hycom.fd/exec/ofs_rivers                      ../exec/ofs_rivers
cp hwrf_hycom.fd/exec/ofs_forcing_add                 ../exec/ofs_forcing_add
cp hwrf_hycom.fd/exec/hwrf_hycom2raw                  ../exec/hwrf_hycom2raw
cp hwrf_hycom.fd/exec/hwrf_ofs_archv2data2d           ../exec/hwrf_ofs_archv2data2d
cp hwrf_hycom.fd/exec/hwrf_ofs_archv2data2d_insitu    ../exec/hwrf_ofs_archv2data2d_insitu
cp hwrf_hycom.fd/exec/hwrf_ofs_archv2data3z           ../exec/hwrf_ofs_archv2data3z
cp hwrf_hycom.fd/exec/hwrf_ofs_archv2data3z_insitu    ../exec/hwrf_ofs_archv2data3z_insitu
cp hwrf_hycom.fd/exec/hwrf_get_layers                 ../exec/hwrf_get_layers 
cp hwrf_hycom.fd/exec/ofs_latlon                      ../exec/ofs_latlon 
cp hwrf_hycom.fd/exec/hwrf_rtofs_reloc_forecast       ../exec/hwrf_rtofs_reloc_forecast
