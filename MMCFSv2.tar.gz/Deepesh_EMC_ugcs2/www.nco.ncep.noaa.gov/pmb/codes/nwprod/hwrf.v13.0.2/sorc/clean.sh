#! /bin/sh

set -x

if [ $# -gt 0 ] && [ $1 == "all" ]; then
    rm -fr ../exec/*
fi

cd ../libs
make clean || true
find . -name '*.a' -o -name '*.o' -o -name '*.mod' -o -name "*.exe" | xargs rm -f
rm -fr make_log

cd ../sorc/hwrf_v4.0.0.fd
./clean -a || true
find . -name '*.o' -o -name '*.a' -o -name '*.mod' -o -name "*.exe" | xargs rm -f
rm -f hwrf_wrf hwrf_real_nmm make_log

cd ../hwrf_gsi.fd/src
make clean || true
find . -name '*.a' -o -name '*.o' -o -name '*.mod' -o -name "*.exe" | xargs rm -f
rm -f hwrf_gsi make_log

cd ../../hwrf_init.fd
find . -name '*.o' -o -name '*.a' -o -name '*.mod' -o -name "*.exe" | xargs rm -f
rm -fr make_log

cd ../hwrf_ncep-coupler.fd
./clean -a || true
find . -name '*.o' -o -name '*.a' -o -name '*.mod' -o -name "*.exe" | xargs rm -f
rm -fr make_log

cd ../hwrf-vortextracker.fd
./clean -a || true
find . -name '*.o' -o -name '*.a' -o -name '*.mod' -o -name "*.exe" | xargs rm -f
rm -f hwrf_gettrk hwrf_tave hwrf_vint
rm -fr make_log

cd ../hwrf_pomtc.fd
./clean -a || true
find . -name '*.o' -o -name '*.a' -o -name '*.mod' -o -name "*.exe" | xargs rm -f
rm -fr make_log

cd ../hwrf_post.fd
./clean -a || true
find . -name '*.o' -o -name '*.a' -o -name '*.mod' -o -name "*.exe" | xargs rm -f
rm -f hwrf_post
rm -fr make_log

cd ../hwrf_tools.fd
find . -name '*.o' -o -name '*.a' -o -name '*.mod' -o -name "*.exe" | xargs rm -f
rm -fr make_log

cd ../hwrf_wps.fd
./clean -a || true
find . -name '*.o' -o -name '*.a' -o -name '*.mod' -o -name "*.exe" | xargs rm -f
rm -f hwrf_metgrid hwrf_geogrid hwrf_ungrib
rm -fr make_log

cd ../hwrf_ww3.fd
./clean -a || true
find . -name '*.o' -o -name '*.a' -o -name '*.mod' -o -name "*.exe" | xargs rm -f
rm -f hwrf_ww3_shel hwrf_ww3_grid hwrf_ww3_prep hwrf_ww3_strt hwrf_ww3_outf hwrf_ww3_outp hwrf_ww3_grib hwrf_ww3_ounf hwrf_ww3_ounp hwrf_ww3_prnc
rm -fr make_log

cd ../hwrf_hycom.fd
./clean -a || true
find . -name '*.o' -o -name '*.a' -o -name '*.mod' -o -name "*.exe" | xargs rm -f
rm exec/hwrf_get_rtofs
rm -fr make_log
