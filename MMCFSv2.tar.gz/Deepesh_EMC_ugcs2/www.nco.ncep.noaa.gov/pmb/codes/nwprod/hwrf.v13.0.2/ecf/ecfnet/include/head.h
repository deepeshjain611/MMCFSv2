set -xe  # print commands as they are executed and enable signal trapping

# Variables needed for communication with ecFlow version %ECF_VERSION%
export ECF_NAME=%ECF_NAME%
export ECF_NODE=%ECF_NODE%
export ECF_PORT=%ECF_PORT%
export ECF_PASS=%ECF_PASS%
export ECF_TRYNO=%ECF_TRYNO%
export ECF_RID=$LSB_JOBID

# Tell ecFlow we have started
if [[ -e /etc/SuSE-release ]] ; then
    # We are on Cray.  Start Cray modules:
    . /opt/modules/default/init/sh
    module use /gpfs/hps3/emc/hwrf/noscrub/ecflow/modulefiles
    module load ncep ecflow_hwrf/intel/4.0.9
else
    # We are on Phase 1 or 2.  Start RedHat modules:
    . /usrx/local/Modules/default/init/sh
    export PATH=/nwprod/ecflow/:$PATH
fi

ecflow_client --init=${ECF_RID}

## Enable LSF to communicate with ecFlow
POST_OUT=${POST_OUT:-/var/lsf/ecflow_post_in.$LSB_BATCH_JID}
if [ -d $(dirname $POST_OUT) ]; then
cat > $POST_OUT <<ENDFILE
ECF_NAME=${ECF_NAME}
ECF_NODE=${ECF_NODE}
ECF_PORT=${ECF_PORT}
ECF_PASS=${ECF_PASS}
ECF_TRYNO=${ECF_TRYNO}
ECF_RID=${ECF_RID}
ENDFILE
fi

# Define error handler
ERROR() {
   set +ex
   if [ "$1" == 0 ]; then
      msg="Killed by signal (likely via bkill)"
   else
      msg="Killed by signal $1"
   fi
   ecflow_client --abort="$msg"
   echo $msg
   echo "Trap Caught" >>$POST_OUT
   trap $1; exit $1
}
# Trap all error and exit signals
trap 'ERROR $?' ERR EXIT

