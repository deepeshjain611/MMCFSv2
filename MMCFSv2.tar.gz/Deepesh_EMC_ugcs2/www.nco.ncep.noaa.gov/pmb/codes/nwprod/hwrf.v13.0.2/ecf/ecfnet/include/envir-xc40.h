# envir-xc40.h
export job=${job:-$LSB_JOBNAME} #Can't use $job in filenames!
export jobid=${jobid:-$job.$LSB_JOBID}

export RUN_ENVIR=${RUN_ENVIR:-emc}
export envir=%ENVIR%
export SENDDBN=${SENDDBN:-%SENDDBN:YES%}
export SENDDBN_NTC=${SENDDBN_NTC:-%SENDDBN_NTC:YES%}

module load prod_envir prod_util

export ROOTDIR=/gpfs/hps3/emc/hwrf/noscrub/ecflow
export COMROOT=${ROOTDIR}/com

export jlogfile=${jlogfile:-${COMROOT}/logs/${envir}/jlogfile}
#export DATAROOT=${DATAROOT:-${ROOTDIR}/tmpnwprd}
export DATAROOT=${DATAROOT:-/gpfs/hps/ptmp/$USER/tmpnw$envir}
export DBNROOT=${UTILROOT}/fakedbn

#export NWROOT=/gpfs/hps/nco/ops/nw${envir}
export NWROOT=$ROOTDIR/nw${envir}
export PCOMROOT=$PCOMROOT/${envir}
export SENDECF=${SENDECF:-YES}
export SENDCOM=${SENDCOM:-YES}
export KEEPDATA=${KEEPDATA:-%KEEPDATA:NO%}
if [ -n "%PDY:%" ]; then export PDY=${PDY:-%PDY:%}; fi


# - temporary debug for sam -

# Override NHC delivery directories:
export COMOUTgltrk=/gpfs/hps3/emc/hwrf/noscrub/ecflow/com/hur/prod/global
export COMOUTatcf=/gpfs/hps3/emc/hwrf/noscrub/ecflow/com/nhc/prod/atcf
#export gltrkdir=${gltrkdir:-${COMROOTp1}/hur/${envir}/global}
#export ATCFdir=${ATCFdir:-${COMROOTp1}/nhc/${envir}/atcf}
