#! /usr/bin/env python

##@namespace ecflow_hwrf
# @brief Generates HWRF ecFlow suite definitions, ecFlow manuals and *.ecf scripts
#
# @details
# Generates suite definition files, *.ecf script templates and ecflow
# manuals for families and jobs.  Knows about the following groups of
# suites:
#
# - hwrfITtests - an ecFlow Suite that runs a sequence of HWRF IT tests on canned 
#     cases
# - ncoprod - production NCO HWRF as four suites, one per cycle
# - ncopara - NCO HWRF parallel as four suites, one per cycle
# - ncotest - NCO test suite for HWRF, a single 12Z cycle
#
# @section ecflow_hwrf_EXEC Executing This Script
#
# This script will generate a suite definition file, sent by default
# to stdout, and a number of scripts, by default in the current
# directory.  All of that can be customized by arguments and options.
#
# Calling convention:
#
#     ecflow_hwrf [options] mode templatefile
#     ecflow_hwrf [options] hwrfITtests templatefile /path/to/com/canned
#
# Arguments:
#
#  * mode - One of:
#      * ncoprod - NCO production suites prod00, ..., prod18
#      * ncopara - NCO parallel suites para00, ..., para18
#      * ncotest - NCO test workflow
#      * hwrfITtests - suite of HWRF IT tests to verify correct
#         functioning of HWRF.  When this mode is selected, the path
#         to the canned COM data must be provided.
#
#  * templatefile - path to the hwrf.tmpl file used to generate
#    scripts and manual pages.
#  * /path/to/com/canned - when hwrfITtests is specified, path to the
#    canned COM data used to run the HWRF IT test suite.  This must not
#    be specified in any other mode.
#
# Options:
#  *  -d /path/to/suite.def - output suite definition file instead of stdout
#  *  -f /path/to/scripts/*.ecf - ECF_FILES path, and location where
#           generated *.ecf files should be stored
#  *  -c cray_target - Cray submission target: xc40bkp, xc40p, surge, luna
#  *  -2 phase2_target - Phase 2 submission target: ibmsp, ibmbkp, tide, gyre

import ecflow, os, sys, re, collections, StringIO, getopt

class DefMaker(object):
    """!Defines one or more ecflow.Suite objects representing some
    workflow to be run.  Performs various actions based on those
    suites."""

    ##@var ecf_files 
    # The value of ECF_FILES set for most suites and families, except
    # for families underneath the per-storm hwrfN level (n=1..7)

    ##@var cray_target
    # Submission target for Cray jobs

    ##@var phase2_target
    # Submission target for Phase 2 jobs

    ##@var ensda_end
    # Number of HWRF ensemble members

    def __init__(self,ecf_files,cray,phase2):
        """!DefMaker constructor.

        @param ecf_files value for the ECF_FILES variable
        @param cray the WCOSS Cray submit target
        @param phase2 the WCOSS Phase 2 submit target"""
        self.ecf_files=os.path.abspath(ecf_files)
        self.__suites=list()
        self.cray_target=cray
        self.phase2_target=phase2
        self.ensda_end=40
        self.__ensda_limit=(self.ensda_end+1)//2

    def suite_iter(self):
        """Iterates over all ecflow.Suite objects created thus far"""
        for suite in self.__suites: yield suite

    def _add_suite(self,suite):
        """Adds an ecflow.Suite to the list of those created by this object.

        This internal function should be called inside any make_def()
        implementation to add the generated Suite objects to the
        internal self.__suites list.

        @param suite The ecflow.Suite to add.
        @protected
        """
        assert(isinstance(suite,ecflow.Suite))
        self.__suites.append(suite)

    def del_suites(self):
        """!Empties the list of suites created thus far.

        This function empties the internal list of suites.  This
        allows the same DefMaker to be reused multiple times to
        generate different suite sets."""
        del self.__suites[:]

    def has_suites(self):
        """!Does this DefMaker have any suites?

        Looks in the internal suite list to see if any suites have
        been generated.  Note that a call to del_suites() will empty
        the list, causing has_suites()==False.  The list also starts
        in an empty state when this object is created.

        @returns True if any suite exists in this object, False otherwise.
        """
        return bool(self.__suites)

    def get_ensda_limit(self): 
        """!How many ENSDA members can run?
        @returns the limit to the number of HWRF ENSDA members that
        can run at once.        """
        return self.__ensda_limit
    def set_ensda_limit(self,limit):
        """!Sets the ENSDA member limit

        Sets the limit to the number of HWRF ENSDA members that can run at any 
        given time.
        @note This limit must be set before calling make_def()
        @param limit the limit, an integer >=1"""
        assert(isinstance(limit,int))
        assert(limit>=1)
        assert(limit<=1000)
        self.__ensda_limit=limit
    ##@property ensda_limit
    # The limit to the number of HWRF ENSDA members that can run at any
    # given time.  Note that this limit must be set BEFORE make_def()
    ensda_limit=property(get_ensda_limit,set_ensda_limit,None,
        "Maximum number of HWRF ensemble members that can run across "
        "the entire suite.")

    def fileset(self):
        """!Walks the entire ecflow.Node tree created by make_def() and
        returns a dict describing the entire tree of *.ecf and *.man
        files to generate.

        @note This will fail unless you first call make_def()

        Calls node_walker() to walk the entire tree of ecflow.Node
        objects created by make_def().  Returns a dict that maps from
        task script (*.ecf) or family/suite man (*.man) file to a list
        of two strings.  The first string is the node type: Task,
        Family or Suite.  The second string is the name of the node;
        the last element of the node's ecflow absolute node path.

        This fileset is not intended to be used directly, but rather
        sent to a ScriptMaker object.  The ScriptMaker will take a
        template file and run it through information in this data
        structure to create all Task *.ecf scripts and Family/Suite
        *.man manual files.        """
        fileset=dict()
        for suite in self.suite_iter():
            self.node_walker(fileset,suite,self.ecf_files)
        return fileset

    def suitedef(self):
        """!Returns the suite definition as a string.  This will raise an
        exception unless you have first called make_def()"""
        assert(self.has_suites())
        return '\n'.join([ str(suite) for suite in self.suite_iter()])

    def node_walker(self,fileset,node,script_dir):
        """!Internal implementation function that walks the ecflow.Node tree
        generating a list of *.ecf and *.man scripts.

        @note This function will raise an exception unless you have
        first called make_def()

        @param fileset A dict mapping from the *.ecf or *.man path to
        a list containing [nodetype, nodename].  The nodetype is the
        type, Task, Family or Suite.  The nodename is the name of the
        node; the last component of the absolute node path.

        @param node The node in the tree currently being processed.

        @param script_dir The directory in which this node's scripts
        should reside, as determined by the last ECF_FILES
        edit/variable found in the heirarchy.  As the node_walker
        walks through the tree, it will append to or replace this path
        as appropriate.

        """
        # NOTE: Tasks have *.ecf scripts, suites and familes have
        # directories and *.man files.  The script_path contains the
        # directory where the file should reside.  That is updated
        # upon recursion.
        nodetype='Unknown'
        nodename=str(node.name())
        nodepath=str(node.get_abs_node_path())
        if isinstance(node,ecflow.Task):
            nodetype='Task'
        elif isinstance(node,ecflow.Suite):
            nodetype='Suite'
        elif isinstance(node,ecflow.Family):
            nodetype='Family'
    
        ecf_files=node.find_variable('ECF_FILES')
        if not ecf_files.empty():
            script_dir=str(ecf_files.value())
            #print '%s: Override script_dir=%s'%(nodepath,script_dir)
    
        if nodetype=='Task':
            script_path=os.path.join(script_dir,nodename+'.ecf')
            fileset[script_path]=[nodetype,nodepath]
            #print '%s: Store ecf file=%s'%(nodepath,script_path)
            return
        elif nodetype=='Unknown':
            raise Exception('%s: node is not a Task, Family or Suite.  Giving up.'
                            %(nodepath,))
    
        man_path=os.path.join(script_dir,nodename+'.man')
        fileset[man_path]=[nodetype,nodepath]
        #print '%s: Store man path=%s'%(nodepath,man_path)
        if not ecf_files.empty():
            child_script_dir=script_dir
        else:
            child_script_dir=os.path.join(script_dir,nodename)
        #print '%s: Recurse with child script_dir=%s'%(nodepath,child_script_dir)
        for child in node.nodes:
            if nodepath != child.get_abs_node_path():
                self.node_walker(fileset,child,child_script_dir)

    def add_events(self,task,events):
        """!Helper function to add events to a task being generated by this
        DefMaker.        """
        for i in xrange(len(events)):
            task.add_event(i+1,events[i])
    
    def make_task(self,name,trigger=None,complete=None,events=None,labels=None,limit=None):
        """Helper function to make an ecflow.Task in this DefMaker

        @param name the task name
        @param trigger the trigger for the task, or None if no trigger
        @param complete the complete for the task, or None if no complete
        @param events a list of event names, or None if no events
        @param labels a list of labels, or None if no labels.  Labels are
          initially set to the string ' ' which is a single space
        @returns a new ecflow.Task"""
        task=ecflow.Task(name)
        if trigger is not None: task.add_trigger(trigger)
        if complete is not None: task.add_complete(complete)
        if events is not None: self.add_events(task,events)
        if limit is not None:  task.add_inlimit(limit)
        if labels is not None:
            for label in labels:
                task.add_label(label,' ')
        return task
    
    def set_launch_trigger(self,launch,cycle):
        launch.add_trigger('cleanup==complete')

    def make_launch(self,num,extra_config,cycle):
        """!Creates the jhwrf_launch job
        @param num the storm number, an integer from 1 to 7
        @param extra_config a string containing extra configuration information
          to be sent to exhwrf_launch.py
        @returns a new ecflow.Task"""
        launch=self.make_task('launch',events=
                         ['NoStorm','Pom','Wave','Gsi','Ensda'])
        launch.add_variable('HWRF_LAUNCH_EXTRA_CONFIG',extra_config)
        self.set_launch_trigger(launch,cycle)
        launch.add_label('storm%d'%num,' ')
        return launch
    
    def make_bufrdump(self):
        """!Makes the jhwrf_bufrdump job, which runs on WCOSS Phase 2 
        instead of Cray.

        @returns the jhwrf_bufrdump job as an ecflow.Task"""
        bufrdump=self.make_task('bufrdump',
            trigger='launch==complete and fgat==complete',
            complete='launch:NoStorm')
        bufrdump.add_variable('SUBMIT_TARGET',self.phase2_target)
        bufrdump.add_variable('ECF_JOB_CMD', '/gpfs/hps3/emc/hwrf/noscrub/ecflow/ecfutils/unixsubmit %ECF_JOB% %ECF_JOBOUT% %SUBMIT_TARGET%')
        return bufrdump
    
    def make_bufrprep(self):
        """!Makes the jhwrf_bufrprep job
        @returns the jhwrf_bufrprep job as an ecflow.Task"""
        return self.make_task('bufrprep',trigger='bufrdump==complete',
                         complete='launch:NoStorm',events=['GsiD02','GsiD03','FoundTDR'])
    
    def make_init_task(self,name,meter=0,trigger=None,complete=None):
        init=self.make_task(name,trigger=trigger,complete=complete)
        init.add_label('status',' ')
        if meter>0:
            init.add_meter(ecflow.Meter('input',0,meter,meter))
        return init

    def make_init(self):
        """!Makes the init family of HWRF jobs, returning them as an
        ecflow.Family

        Creates the init family, containing ocean_init, wave_init,
        init_gfs, bdy and relocate_gfs jobs as ecflow.Task objects.
        Places them together in an ecflow.Family with appropriate
        trigger and complete conditions, and returns it.
        
        @returns an ecflow.Family for the init family of HWRF jobs
        """
        init=ecflow.Family('init')
        init.add_trigger('launch==complete')
        init.add_complete('launch:NoStorm')
        init.add_task(self.make_task('ocean_init',complete='../launch:Pom==clear',
                                events=['Pom'],labels=['method','wake']))
        init.add_task(self.make_task('wave_init',complete='../launch:Wave==clear',
                                events=['Wave']))
        init.add_task(self.make_init_task('init_gfs'))
        init.add_task(self.make_init_task(
            'bdy',trigger='init_gfs==complete',meter=126))
        init.add_task(self.make_task('relocate_gfs',trigger='init_gfs==complete',
                                labels=['cycling']))
        return init
    
    def make_fgat(self):
        """!Creates the fgat family of HWRF jobs, returning them as an
        ecflow.Family.

        Creates the fgat family, containing init_GDAS_(N) and
        relocate_GDAS_(N) for N=3, 6, and 9.  Each job processes
        forecast hour N from the previous cycle of GDAS.

        @returns the resulting ecflow.Family"""

        fgat=ecflow.Family('fgat')
        fgat.add_complete('launch==complete and ( launch:Gsi==clear or '
                          'launch:NoStorm )')
        fgat.add_trigger('launch==complete')
        for s in '369':
            fgat.add_task(self.make_init_task('init_gdas_'+s))
    
        for s in '369':
            fgat.add_task(self.make_task('relocate_gdas_'+s,labels=['cycling'],trigger=
              'init_gdas_'+s+'==complete and ../init/init_gfs==complete'))
        return fgat
    
    def make_gsi(self):
        """!Makes the "gsi" family of HWRF jobs, returning it as an ecflow.Family.

        Creates an ecflow.Family containing ecflow.Task objects for
        the domain 2 and 3 GSI (gsi_d02 and gsi_d03) plus the merge
        job that runs after them.

        @returns the resulting ecflow.Family"""

        gsi=ecflow.Family('gsi')
        gsi.add_complete('launch==complete and ( launch:Gsi==clear or '
                         'launch:NoStorm )')
        gsi.add_trigger('fgat==complete and init/init_gfs==complete and '
                        'bufrprep==complete')
        gsi.add_task(self.make_task('gsi_d02',complete='../bufrprep==complete and '
                               '../bufrprep:GsiD02==clear',events=['canceled']))
        gsi.add_task(self.make_task('gsi_d03',complete='../bufrprep==complete and '

        '../bufrprep:GsiD03==clear',events=['canceled']))
        gsi.add_task(self.make_task(
            'merge',trigger='gsi_d02==complete and gsi_d03==complete',
            complete='( ../bufrprep==complete and ../bufrprep:GsiD02==clear '
            'and ../bufrprep:GsiD03==clear ) or gsi_d03:canceled or '
            'gsi_d02:canceled'))
        return gsi
    
    def make_gsi_post(self):
        """!Creates the gsi_post ecflow.Task
        @returns an ecflow.Task that runs the JHWRF_GSI_POST job."""
        return self.make_task('gsi_post',complete=
          'launch==complete and bufrprep==complete and (  '

        'launch:Gsi==clear or launch:NoStorm or ( bufrprep:GsiD02==clear '
          'and bufrprep:GsiD03==clear ) )',
          trigger='gsi==complete')
    
    def make_model(self,top=''):
        """!Creates the "model" family of HWRF tasks.

        Creates a family containing all possible HWRF forecast tasks.
        Only one of these tasks will be run automatically by the
        workflow, though it is possible for another to be forced
        manually to run.

        @param top Used to find the init family.  It is at
        ../../(top)/init.  This is used to support putting the init
        family in a totally different part of the workflow than the
        model family, such as when running the model repeatedly, many
        times.
        @returns the resulting ecflow.Family"""
        model=ecflow.Family('model')
        wrfww3ocn=self.make_task('wrfww3ocn',complete=
            '../../%sinit==complete and ( ../../%sinit/ocean_init:Pom==clear or '
            '../../%sinit/wave_init:Wave==clear )'%(top,top,top))
        wrfww3ocn.add_variable('FORECAST_CONF_OVERRIDE',' ')
        model.add_task(wrfww3ocn)

        wrfocn=self.make_task('wrfocn',complete=
           '../../%sinit==complete and ../../%sinit/ocean_init:Pom==clear or '
           '( ../../%sinit/ocean_init:Pom==set and ../../%sinit/wave_init:Wave==set )'
           %(top,top,top,top))
        wrfocn.add_variable('FORECAST_CONF_OVERRIDE','config.run_wave=no')
        model.add_task(wrfocn)

        wrf=self.make_task(
            'wrf',complete='../../%sinit/ocean_init:Pom==set'%(top,))
        wrf.add_variable('FORECAST_CONF_OVERRIDE',
                         'config.run_wave=no config.run_ocean=no')
        model.add_task(wrf)

        safe=self.make_task('failsafe')
        safe.add_defstatus(ecflow.DState.complete)
        safe.add_variable('FORECAST_CONF_OVERRIDE',

        'config.run_wave=no config.run_ocean=no '
                          'config.run_gsi=no '
                          'moad_namelist.dynamics.dwdt_damping_lev=7000.0')
        model.add_task(safe)

        return model
    
    def make_post_task(self,name):
        """!Creates one copy of the jhwrf_post job

        The jhwrf_post can be run many times in parallel.  The copies
        will automatically work together to run the NCEP post on all
        wrfout files twice, once for the each of the pressure and
        satellite cases.  The coordination between jobs is done via an
        sqlite3 database file and lock files.

        @param name the name of the job
        @returns the resulting ecflow.Task """
        task=self.make_task(name,trigger='unpost==complete')
        task.add_meter(ecflow.Meter('model',0,126,126))
        task.add_meter(ecflow.Meter('pressure',0,126,126))
        task.add_meter(ecflow.Meter('satellite',0,126,126))
        return task

    def make_post(self,top=''):
        """!Makes the post ecflow.Family that runs all HWRF ocean and
        atmosphere post-processing.

        Generates an ecflow.Family containing a jhwrf_unpost job, two
        jhwrf_post jobs, and a jhwrf_products job.

        @param top Used to find the init family, which is at
        ../../(top)/init.
        @returns the resulting ecflow.Family"""
        post=ecflow.Family('post')
        post.add_trigger('model==complete or model==active')
        post.add_task(self.make_task('unpost'))
        post.add_task(self.make_post_task('post1'))
        post.add_task(self.make_post_task('post2'))
        products=self.make_task('products',trigger=
            'post1==complete or post1==active or post2==complete or post2==active',
            events=['SentTrackToNHC'])
        products.add_meter(ecflow.Meter('gribber',0,126,126))
        products.add_meter(ecflow.Meter('tracker',0,126,126))
        post.add_task(products)
        return post
    
    def make_forecast(self,name='forecast',top=''):
        forecast=ecflow.Family(name)
        forecast.add_complete('%slaunch==complete and %slaunch:NoStorm'%(top,top))
        forecast.add_trigger('%sfgat==complete and %sgsi==complete and %sinit==complete'%(top,top,top))
        forecast.add_family(self.make_model(top))
        forecast.add_family(self.make_post(top))
        forecast.add_task(
            self.make_task('wave_post',complete='../%sinit==complete and '
                           '( ../%sinit/ocean_init:Pom==clear or '
                           '../%sinit/wave_init:Wave==clear )'%(top,top,top),
                           trigger='model/wrfww3ocn==complete'))
        forecast.add_task(self.make_task('output',trigger='model==complete and '
            'post/products==complete and ../%sgsi_post==complete'%(top,),
            events=['emailSDM','wrfdiag']))
        return forecast
    
    def set_ensda_pre_triggers(self,ensda_pre,cycle):
        pass

    def make_ensda(self,cycle):
        ensda=ecflow.Family('ensda')
        ensda.add_complete('launch==complete and ( launch:NoStorm or launch:Ensda==clear )')
        ensda.add_trigger('forecast/output==complete')
        ensda_pre=self.make_task('ensda_pre',events=['Ensda'])
        self.set_ensda_pre_triggers(ensda_pre,cycle)
        ensda.add_task(ensda_pre)
        prior=None

        eend=self.ensda_end
        elimit=self.ensda_limit

        ensfam=ecflow.Family('ensda_members')
        ensfam.add_trigger('ensda_pre==complete')
        ensfam.add_complete('ensda_pre==complete and ensda_pre:Ensda==clear')
        for ensid in range(1, eend+1):
            ensfam.add_task(self.make_task('ensmem%02d'%ensid,limit=
                ecflow.InLimit('hwrf_ensda_limit')))
        ensda.add_family(ensfam)

        ensda_output=self.make_task(
            'ensda_output',complete='ensda_pre==complete and '
                                    'ensda_pre:Ensda==clear')
        ensda_output.add_trigger('ensda_members==complete')
        ensda.add_task(ensda_output)

        return ensda
    
    def make_hwrf(self,name,num,cycle,extra_config='',modify_forecast=None):
        if not isinstance(cycle,int) or cycle not in [0, 6, 12, 18]:
            raise ValueError('Invalid cycle %s must be 0, 6, 12 or 18 as an int.'%(repr(cycle),))
        hwrf=ecflow.Family(name)
        hwrf.add_variable('ECF_FILES',self.ecf_files)
        assert(int(name[4:])==num)
        hwrf.add_variable('STORMNUM','%d'%num)
        hwrf.add_task(self.make_task('cleanup'))
        hwrf.add_task(self.make_launch(num,extra_config,cycle))
        hwrf.add_family(self.make_init())
        hwrf.add_family(self.make_fgat())
        hwrf.add_task(self.make_bufrdump())
        hwrf.add_task(self.make_bufrprep())
        hwrf.add_family(self.make_gsi())
        hwrf.add_task(self.make_gsi_post())
        forecast=self.make_forecast()
        if modify_forecast is not None:
            forecast=self.modify_forecast(forecast)
        if forecast is None: return hwrf
        hwrf.add_family(forecast)
        hwrf.add_family(self.make_ensda(cycle))
        return hwrf
    
    def add_suite_vars(self,s):
        s.add_limit('hwrf_ensda_limit', self.ensda_limit)

        s.add_variable('QUEUE', 'devonprod')
        s.add_variable('PROJ', 'HWRF')
        s.add_variable('SHAREDQ', 'devonprod')
        s.add_variable('IBMSPQUEUE', 'devonprod2')
        s.add_variable('SERVQ', 'dev_transfer')
        
        s.add_variable('COM_OUTPUT', '/gpfs/hps/ptmp/emc.hurpara/ecflow/com/output')
        s.add_variable('SCRUBDIR', '/gpfs/hps/ptmp/emc.hurpara/tmpnwprd')
        s.add_variable('NWBASE', '/gpfs/hps3/emc/hwrf/noscrub/ecflow/nw')
        
        s.add_variable('E', 'd')
        s.add_variable('ENVIR', 'dev')
        s.add_variable('PROJENVIR','T2O')
        
        s.add_variable('ECF_INCLUDE', '/gpfs/hps3/emc/hwrf/noscrub/ecflow/ecfnets/include')
        s.add_variable('ECF_FILES', self.ecf_files)
        s.add_variable('ECF_OUT','/gpfs/hps3/emc/hwrf/noscrub/ecflow/com/output/dev/')
                       
        s.add_variable('ECF_TRIES', '1')
        s.add_variable('SUBMIT_TARGET',self.cray_target)
        s.add_variable('ECF_JOB_CMD', '/gpfs/hps3/emc/hwrf/noscrub/ecflow/ecfutils/unixsubmit %ECF_JOB% %ECF_JOBOUT% %SUBMIT_TARGET%')
        s.add_variable('ECF_KILL_CMD', '/gpfs/hps3/emc/hwrf/noscrub/ecflow/ecfutils/unixkill %ECF_NAME% %ECF_JOBOUT%')
    
    def make_def(self,name):
        raise NotImplementedError('This is an abstract base class.  You must use a subclass instead.')

########################################################################

########################################################################

class DefNCOHWRF(DefMaker):
    def __init__(self,ecf_files,cray,phase2,nstorms,envir):
        super(DefNCOHWRF,self).__init__(ecf_files,cray,phase2)
        assert(envir in ['test','prod','para'])
        self.nstorms=nstorms
        self.cycs=[0,6,12,18]
        self.__envir=None
        self.envir=envir

    def set_envir(self,envir):
        if envir not in ['prod','para','test','eval','dev']:
            raise ValueError('The envir must be in the set { "prod", "para", '
                             '"test", "eval", "dev" } but you specified %s.'
                             %(envir,))
        self.__envir=envir
    def get_envir(self): return self.__envir
    envir=property(get_envir,set_envir,None,
        'The environment in which to run: prod, para, test, eval or dev.')

    ##@property envir
    # The environment in which to run: "prod", "para", "test", "eval" or "dev".

    @property
    def envir1letter(self):
        """!The one-letter version of envir"""
        envir=self.envir
        if envir=='prod':   return 'j'
        elif envir=='para': return 'p'
        elif envir=='test': return 't'
        elif envir=='eval': return 'e'
        elif envir=='dev':  return 'd'
        else:
            raise ValueError('The envir must be prod, para, test, eval or dev.')

    def set_ensda_pre_triggers(self,ensda_pre,cycle):
        ensda_pre.add_trigger('/prod%02d/gdas/enkf/jgdas_enkf_post==complete'
                              %cycle)

    def set_launch_trigger(self,launch,cycle):
        launch.add_trigger(
            'cleanup==complete and '
            '/prod%02d/gfs/prdgen/jgfs_pgrb2_manager:release_pgrb2_00'%cycle)

    def add_suite_vars(self,s):
        s.add_limit('hwrf_ensda_limit', self.ensda_limit)

        s.add_variable('QUEUE', 'prod')
        s.add_variable('PROJ', 'HWRF')
        s.add_variable('SHAREDQ', 'prod_shared')
        s.add_variable('IBMSPQUEUE', 'prod2')
        s.add_variable('SERVQ', 'prod_transfer')
        
        s.add_variable('ECF_JOB_CMD', '/ecf/ecfutils/unixsubmit %ECF_JOB% %ECF_JOBOUT% %SUBMIT_TARGET%')
        s.add_variable('COM_OUTPUT', '/gpfs/hps/nco/ops/com/output')
        s.add_variable('SCRUBDIR', '/gpfs/hps/nco/ops/tmpnwprd')
        s.add_variable('NWBASE', '/gpfs/hps/nco/ops/nw')
        
        s.add_variable('E', self.envir1letter)
        s.add_variable('ENVIR', self.envir)
        s.add_variable('PROJENVIR','OPS')
        
        s.add_variable('ECF_INCLUDE', '/gpfs/hps/nco/ops/ecf/ecfnets/include/')
        s.add_variable('ECF_FILES', self.ecf_files)
        s.add_variable('ECF_OUT',
                       os.path.join('/gpfs/hps/nco/ops/com/output/',self.envir))
        s.add_variable('ECF_TRIES', '1')
        s.add_variable('SUBMIT_TARGET',self.cray_target)
        s.add_variable('ECF_KILL_CMD', '/gpfs/hps/nco/ops/ecf/ecfutils/unixkill %ECF_NAME% %ECF_JOBOUT%')
    
    def make_def(self,name):
        nstorms=self.nstorms
        cycs=self.cycs
        envir=self.envir
        prior=None
        for j in xrange(len(cycs)):
            icyc=cycs[j]
            me='testprod%02d'%icyc
            envircyc=ecflow.Suite('%s%02d'%(envir,icyc))
            self.add_suite_vars(envircyc)
            hwrf=ecflow.Family('hwrf')
            for ihwrf in xrange(nstorms):
                hwrf.add_family(self.make_hwrf(
                    'hwrf%d'%(ihwrf+1),ihwrf+1,icyc))
            envircyc.add_family(hwrf)
            self._add_suite(envircyc)

########################################################################
    
class DefITTests(DefMaker):
    def __init__(self,ecf_files,cray,phase2,com_canned):
        assert(com_canned is not None)
        assert(com_canned)
        super(DefITTests,self).__init__(ecf_files,cray,phase2)
        self.com_canned=com_canned
    
    def make_it_test(self,name,com_canned,cycles,nstorms,
                     morevars=None,extra_config=None):
        s=ecflow.Family(name)
        s.add_variable('ECF_FILES',self.ecf_files)
    
        if morevars is not None: s.add_variable(morevars)
    
        for j in xrange(len(cycles)):
            cyc=cycles[j]
            f=ecflow.Family('ITtest'+cyc[-2:])
            f.add_variable('ECF_FILES',self.ecf_files)
            if len(cycles)>1 and j>0:
                f.add_trigger('ITtest%s==complete'%cycles[j-1][-2:])
            f.add_variable('CYC',cyc[-2:])
            f.add_variable('PDY',cyc[0:-2])
            f.add_variable('COM_CANNED',com_canned)
            for istorm in xrange(nstorms):
                h=self.make_hwrf('hwrf%d'%(istorm+1),istorm+1,int(cyc[-2:],10),
                                 extra_config=extra_config)
                f.add_family(h)
            s.add_family(f)
        return s

    def make_def(self,name):
        s=ecflow.Suite(name)
        self.add_suite_vars(s)
    
        it_test_conf='config.allow_fallbacks=no failure.loop_current=unexpected_failure'

        # staged_TDR - two cycle staged data TDR test.  This runs the
        # ENSDA for one cycle.  For the second cycle, it runs the full
        # data assimilation, with TDR.  There is a "dcom" subdirectory of
        # the canned com with the canned dcom.  That is used as $DCOMROOT.
        staged_TDR=self.make_it_test(
            'staged_TDR',os.path.join(self.com_canned,'staged_TDR'),
            ['2014091512','2014091518'], 7,
            extra_config=it_test_conf + ' config.expect_tdr=yes')
        s.add_family(staged_TDR)
    
        # basin_CELW = tests north pacific and north atlantic basin storms
        #
        # Expectation: all storms run to completion with ocean coupling.
        # L and E storms use wave coupling too.
        basin_CELW=self.make_it_test(
            'basin_CELW',os.path.join(self.com_canned,'basin_CELW'),
            ['2015100412','2015100418'], 7,
            extra_config=it_test_conf)
        basin_CELW.add_trigger('staged_TDR==complete')
        s.add_family(basin_CELW)
    
        # basin_AES = tests Arabian Sea (North West Indian Ocean), North
        # East Pacific, and Southern Pacific storms.
        #
        # Expectation: all storms run to completion.  North East Pacific
        # storm runs with data assimilation, and couples to both ocean and
        # wave models.  The Arabian Sea storm runs with ocean coupling,
        # but not wave coupling, and not data assimilation.  Southern
        # Pacific storm runs with all three components off: no ocean, wave
        # nor data assimilation.
        basin_AES=self.make_it_test(
            'basin_AES',os.path.join(self.com_canned,'basin_AES'),
            ['2015102512','2015102518'], 7,
            extra_config=it_test_conf)
        basin_AES.add_trigger('basin_CELW==complete')
        s.add_family(basin_AES)
    
        # basin_BELPW = tests Arabian Sea (North West Indian Ocean), North
        # East Pacific, and Southern Pacific storms.
        #
        # Expectation: all storms run to completion.  North East Pacific
        # storm runs with data assimilation, and couples to both ocean and
        # wave models.  The Arabian Sea storm runs with ocean coupling,
        # but not wave coupling, and not data assimilation.  Southern
        # Pacific storm runs with all three components off: no ocean, wave
        # nor data assimilation.
        basin_BELPW=self.make_it_test(
            'basin_BELPW',os.path.join(self.com_canned,'basin_BELPW'),
            ['2015073000','2015073006'], 7,
            extra_config=it_test_conf)
        basin_BELPW.add_trigger('basin_CELW==complete')
        s.add_family(basin_BELPW)

        basins_done='basin_BELPW==complete && basin_AES==complete'
    
        # Single cycle test of 2016 Alex 01L.  This case failed in
        # operations due to numerical instability issues coming from
        # interactions with a 150m/s polar stratospheric vortex at the
        # model top.  Dynamics changes in 2016 HWRF should fix this.
        # (Smaller timestep, model top vertical advection damping, various
        # other changes.)  A single cycle test of the first cycle should
        # be enough since that was the worst cycle.  Two other storms
        # exist at the same time; alex is storm #2.  All three storms will
        # run to completion.
        alex=self.make_it_test(
            'alex',os.path.join(self.com_canned,'alex'),
            ['2016011218'], 7,
            extra_config=it_test_conf)
        alex.add_trigger(basins_done)
        s.add_family(alex)
    
        # greenwich - Greenwich line (0 Longitude) crossing storm.  
        greenwich=self.make_it_test(
            'greenwich',os.path.join(self.com_canned,'greenwich'),
            ['2014090706'], 7,
            extra_config=it_test_conf)
        greenwich.add_trigger(basins_done)
        s.add_family(greenwich)
    
        # dateline - Dateline (+/-180 Longitude) crossing storm.  
        dateline=self.make_it_test(
            'dateline',os.path.join(self.com_canned,'dateline'),
            ['2013081800'], 7,
            extra_config=it_test_conf)
        dateline.add_trigger(basins_done)
        s.add_family(dateline)
    
        self._add_suite(s)

########################################################################

class DefRepeat1Storm(DefMaker):
    def __init__(self,ecf_files,cray,phase2,com_canned):
        super(DefRepeat1Storm,self).__init__(ecf_files,cray,phase2)
        self.com_canned=com_canned
    
    def repeat_ten_times(self,fcst):
        fcst.add_repeat(ecflow.RepeatInteger("iteration",1,10))
        return fcst
    
    def make_def(self,name):
        s=ecflow.Suite(name)
        add_suite_vars(s)
        s.add_variable('PDY','20130913')
        s.add_variable('COM_CANNED',self.com_canned)
        s.add_variable('CYC','12')
        s.add_family(self.make_hwrf("hwrf1",1,12,modify_forecast=self.repeat_ten_times))
        self._add_suite(s)

########################################################################

class DefRepeat7Storm(DefMaker):
    def __init__(self,ecf_files,cray,phase2,com_canned):
        super(DefRepeat1Storm,self).__init__(ecf_files,cray,phase2)
        self.com_canned=com_canned

    def make_def(self,name):
        s=ecflow.Suite(name)
        add_suite_vars(s)
        s.add_variable('PDY','20130913')
        s.add_variable('COM_CANNED',self.com_canned)
        s.add_variable('CYC','12')
        preps=ecflow.Family('preps')
        for i in xrange(7):
            hwrf=self.make_hwrf("hwrf%d"%(i+1),i+1,12,
                           modify_forecast=lambda x: None)
            preps.add_family(hwrf)
        s.add_family(preps)
    
        fcsts=ecflow.Family('fcsts')
        fcsts.add_trigger('preps==complete')
        fcsts.add_repeat(ecflow.RepeatInteger("iteration",1,4))
        for i in xrange(7):
            hwrf=make_forecast(name='hwrf%d'%(i+1),top='../preps/hwrf%d/'%(i+1))
            hwrf.add_variable('STORMNUM','%d'%(i+1))
            fcsts.add_family(hwrf)
        s.add_family(fcsts)

        self._add_suite(s)

########################################################################
    
    
class ecabort(object):
    def __init__(self,why):
        self.why=why
    def __str__(self): return 'ABORT DIRECTIVE: #*ecabort '+self.why+'\n'
    def __repr__(self): return "ecabort(%s)"%(repr(self.why),)
    
class ecdone(object):
    def __init__(self,why):
        self.why=why
    def __str__(self): return 'DONE DIRECTIVE: #*ecdone\n'
    def __repr__(self): return "ecdone"
    
class ScriptMaker(object):
    def __init__(self):
        self.iline=0
        self.bad=False
        self.template=None

    def reset_iline(self):
        self.iline=0

    def complain(self,cfile,message):
        self.bad=True
        sys.stderr.write('%s:%d: %s\n'%(cfile,self.iline,str(message)))

    def read_template(self,templatefile):
        self.reset_iline()
        self.bad=False

        template=list()
    
        ecorder=None
        ecwhen=None
        eccond=None
        ecdone=None

        with open(templatefile,'rt') as tf:
            for line in tf:
                self.iline+=1
                m=re.match('^\s*#\*\s*ec\s*(.*)$',line)
                if not m:
                    if ecwhen is None:
                        # Regular text line, outside of ecwhen/else/end block
                        template.append(line)
                    elif isinstance(ecwhen[eccond],ecabort):
                        pass # Text after ecabort in ecwhen/else/end block
                    else:
                        # Text inside ecwhen or ecelse block
                        ecwhen[eccond].write(line)
                    continue
                cmd=m.group(1) # everything after #*ec
        
                m=re.match('done\s*$',cmd)
                if m:
                    if ecwhen is None:
                        self.complain(templatefile,
                                      'ecdone outside ecwhen/else/end block: '+m.group(1))
                    ecdone[eccond]=True
            
                m=re.match('abort\s+(.*)$',cmd)
                if m:
                    if ecwhen is None:
                        self.complain(templatefile,
                                 'ecabort outside ecwhen/else/end block: '+m.group(1))
                    else:
                        if isinstance(ecwhen[eccond],StringIO.StringIO):
                            ecwhen[eccond].close()
                        ecwhen[eccond]=ecabort(m.group(1))
                m=re.match('when\s+(\S+)\s*$',cmd)
                if m:
                    if ecwhen is None:
                        ecwhen=collections.defaultdict(StringIO.StringIO)
                        ecdone=collections.defaultdict(lambda: False)
                        ecorder=list()
                    eccond=m.group(1)
                    ecorder.append(eccond)
                    continue
                if re.match('else\s*$',cmd):
                    if ecwhen is None:
                        self.complain(templatefile,'ecelse without ecwhen')
                        ecwhen=collections.defaultdict(StringIO.StringIO)
                        ecdone=collections.defaultdict(lambda: False)
                    eccond=''
                    ecorder.append('')
                    continue
                if re.match('end\s*$',cmd):
                    if ecwhen is None:
                        self.complain(templatefile,'ecend without ecwhen')
                        continue
                    for cond in ecorder:
                        stream=ecwhen[cond]
                        if isinstance(stream,ecabort):
                            continue
                        assert(isinstance(stream,StringIO.StringIO))
                        ecwhen[cond]=stream.getvalue()
                        stream.close()
                        del stream
                    template.append([ecorder,ecwhen,ecdone])
                    eccond=None
                    ecdone=None
                    ecwhen=None
                    ecorder=None
    
        if self.bad: template=None
        self.template=template
        return template
    
    def strsub(self,cfile,instring,task,matches=None):
        """!Substitues strings with variable name contents while generating
        output files.

        String substitution code that represents &[varname] where
    
        - nodepath, taskpath = full path to task in ecflow
        - nodename, node, taskname or task = just the task name
        - NODENAME, NODE, TASKNAME or TASK = capitalized task  name
        - &[&] = a single ampersand ("&")
        - 1, 2, 3, etc. = capture group from regular expression inside
          an ecwhen block

        @param cfile the input file name for error reporting
        @param instring input string to parse
        @param task absolute node path

        @param matches Optional: array of regular expression matches
        for special variable names 1, 2, 3 etc.

        @returns the result of replacing variable names in instring        """
        outstr=StringIO.StringIO()
        for entry in re.split('(&\[[^\]]*\])',instring):
            if entry[0:2]=='&[' and entry[-1]==']':
                svar=entry[2:-1]
                if svar in ['taskpath','nodepath']:
                    outstr.write(task)
                elif svar in ['taskname','task','nodename','node']:
                    outstr.write(re.sub('.*/','',task))
                elif svar in ['TASKNAME','TASK','NODENAME','NODE']:
                    outstr.write(re.sub('.*/','',task.upper()))
                elif svar=='&':
                    outstr.write('&')
                elif re.match('^\d+$',svar):
                    if matches is None:
                        self.complain(cfile,'no matches in this block for %s in %s'%(
                            entry,repr(instring)))
                        continue
                    imatch=int(svar,10)
                    try:
                        smatch=matches.group(imatch)
                    except IndexError as e:
                        self.complain(cfile,'no match %d in this block for %s in %s'%(
                            imatch,entry,repr(instring)))
                        continue
                    outstr.write(smatch)
                else:
                    self.complain(cfile,'unknown variable %s in %s'%(svar,repr(instring)))
            else:
                outstr.write(entry)
        outstring=outstr.getvalue()
        outstr.close()
        return outstring
    
    def make_scripts(self,fileset):
        for filename,typepath in fileset.iteritems():
            self.reset_iline()
            (nodetype, nodepath) = typepath
            # man=True means this is a man page for suite or family so
            #       only print contents of ecwhen blocks, and include
            #       ".man" for search strings of an ecwhen
            # man=False means this is a task, so print anything that
            #       matches, including outside #*ecwhen.  Only use the node
            #       path for ecwhen string matching.
            man = nodetype in ['Family','Suite']
            searchstring=nodepath
            if man:
                searchstring+='.man'
            dirpath=os.path.dirname(filename)
            if not os.path.isdir(dirpath):
                os.makedirs(dirpath)
            with open(filename,'wt') as tf:
                self.write_template_for(filename,nodetype,nodepath,searchstring,tf)

    def write_template_for(self,filename,nodetype,nodepath,searchstring,tf):
        for line in self.template:
            self.iline+=1
            if isinstance(line,basestring):
                if nodetype=='Task':
                    tf.write(self.strsub(filename,line,nodepath))
                continue
            (ecorder,ecwhen,ecdone)=line
            for eccond in ecorder:
                if eccond:
                    m=re.search(eccond,searchstring)
                    if not m: continue
                else:
                    m=None
                ecwhat=ecwhen[eccond]
                if isinstance(ecwhat,ecabort):
                    abortmsg=self.strsub(filename,ecwhat.why,nodepath,m)
                    self.complain(filename,'abort: '+abortmsg)
                else:
                    tf.write(self.strsub(filename,ecwhat,nodepath,m))
                if ecdone[eccond]:
                    return
                break
    
########################################################################

##@var mode which suite or set of suites to generate

##@var templatefile path to hwrf.tmpl file

##@var com_canned path to canned com directory

##@var ecf_files ECF_FILES variable name and path to the *.ecf files

##@var def_file output *.def filename instead of stdout

##@var cray_target submit target for Cray jobs

##@var phase2_target submit target for Phase 2 jobs
    
mode=None
templatefile=None
com_canned=None

ecf_files=None
def_file=None

cray_target='xc40p'
phase2_target='ibmsp'

def usage(why=None):
    """!Prints a usage message and exits.

    @param why if present, appended to the end of the usage message
    after the string "ABORTING:" and usage will exit with status 1.
    If not present, usage exits with status 0.

    @returns Never.  Program exits with status 0 or 1."""

    msg="""Syntax: 
     %s [options] mode templatefile
     %s [options] hwrfITtests templatefile /path/to/com/canned

PURPOSE: Generates HWRF ecFlow suite definition, script files, and
manual files for families and suites.

ARGUMENTS:

mode - One of:
  ncoprod - NCO production suites prod00, ..., prod18
  ncopara - NCO parallel suites para00, ..., para18
  ncotest - NCO test workflow

  hwrfITtests - suite of HWRF IT tests to verify correct functioning
     of HWRF.   When this mode is selected, the path to the canned
     COM data must be provided.

templatefile - path to the hwrf.tmpl file used to generate scripts and
  manual pages.

/path/to/com/canned - when hwrfITtests is specified, path to the
  canned COM data used to run the HWRF IT test suite.  This must not
  be specified in any other mode.

Options:
  -d /path/to/suite.def - output suite definition file instead of stdout
  -f /path/to/scripts/*.ecf - ECF_FILES path, and location where
       generated *.ecf files should be stored
  -c cray_target - Cray submission target: xc40bkp, xc40p, surge, luna
  -2 phase2_target - Phase 2 submission target: ibmsp, ibmbkp, tide, gyre
%s"""
    exe=os.path.basename(sys.argv[0])
    if why:
        sys.stderr.write(msg%(exe, exe, "\nABORTING: %s\n"%(why,)))
        exit(1)
    else:
        print msg%(exe, exe, "")
        exit(0)

def parseargs():
    """!Parses arguments from sys.argv, calling usage() and aborting on
    argument error."""
    global mode, templatefile, com_canned, ecf_files, def_file
    global cray_target, phase2_target

    if len(sys.argv)<2:
        usage("No arguments provided.")

    optlist, args = getopt.getopt(sys.argv[1:],'d:c:2:f:')
    if not args or len(args)<1:
        usage("No non-option arguments provided.")
    if args[0]=='hwrfITtests':
        if len(args)!=3:
            usage('In hwrfITtests mode, you must provide exactly three non-option arguments (got %d).'%len(args))
        (mode,templatefile,com_canned)=args
    elif len(args)!=2:
        usage('Expected exactly two non-option arguments in this mode.')
    else:
        (mode,templatefile)=args
        assert(mode != 'hwrfITtests')

    if mode not in ['hwrfITtests', 'ncoprod', 'ncopara', 'ncotest']:
        usage("Unknown mode "+mode)
    
    def_file=mode+'.def'
    ecf_files=mode

    for (opt,val) in optlist:
        if opt=='-d':            def_file=val
        elif opt=='-c':          cray_target=val
        elif opt=='-2':          phase2_target=val
        elif opt=='-f':          ecf_files=val
        else:
            usage('Unknown option '+repr(opt))

    ecf_files=os.path.abspath(ecf_files)

########################################################################

def main():
    """!Main program run when this module is executed as a script."""
    parseargs()
    if mode in ['ncopara', 'ncotest', 'ncoprod']:
        deffer=DefNCOHWRF(ecf_files,cray_target,phase2_target,7,mode[3:])
    elif mode=='hwrfITtests':
        assert(com_canned is not None)
        deffer=DefITTests(ecf_files,cray_target,phase2_target,com_canned)
    else:
        usage('Unrecognized mode "%s" must be "hwrf" or "hwrfITtests".'%(mode,))

    # Make the suite:
    deffer.make_def(mode)
    suitedef=deffer.suitedef()
    
    # Walk the definition tree to find out what *.ecf and *.man we need:
    fileset=deffer.fileset()

    # Make scripts:
    sm=ScriptMaker()
    sm.read_template(templatefile)
    sm.make_scripts(fileset)

    # List scripts:
    #for ( filename, typename ) in fileset.iteritems():
    #    (nodetype,nodename) = typename
    #    print "%s %s => %s"%(nodetype,nodename,filename)
    
    # Print def:
    with open(def_file,'wt') as df:
        df.write('%s\n'%(suitedef,))

########################################################################

if __name__=='__main__':
    main()
