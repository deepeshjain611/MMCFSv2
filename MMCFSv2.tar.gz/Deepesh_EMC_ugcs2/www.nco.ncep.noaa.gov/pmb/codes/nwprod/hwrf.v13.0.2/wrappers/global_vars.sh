############################################################
#
# 	Definition of global variables for an HWRF case
#
############################################################


##### Definition of the Storm ######
export START_TIME=2016100400	# Initial start date
export SID=14L  		# Storm ID
export CASE=HISTORY		# HISTORY OR FORECAST


##### Location of HWRF installation #####
export HOMEhwrf=/PATH/TO/HWRF/DIRECTORY

export EXPT=`echo ${HOMEhwrf} | rev | cut -d/ -f1 | rev`

##### File containing the case-specific variables defined in launcher #####
# Note: If multistorm. '{SID}' is needed in the startfile name
export startfile=${HOMEhwrf}/wrappers/${EXPT}-${START_TIME}-${SID}.start

