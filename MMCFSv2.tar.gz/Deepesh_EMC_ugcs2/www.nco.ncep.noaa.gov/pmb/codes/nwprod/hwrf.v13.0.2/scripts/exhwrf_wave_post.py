#! /usr/bin/env python

"""This script runs the wave post processor when wave_model==WW3"""

import sys, os
import produtil.setup, produtil.log
from produtil.log import jlogger

def main():
    import hwrf_expt
    hwrf_expt.init_module(make_ensemble_da=False)

    import hwrf_alerts
    hwrf_alerts.add_wave_alerts()
    hwrf_alerts.add_ww3prod_alerts()

    conf=hwrf_expt.conf
    wave_flag=conf.getbool('config','run_wave')
    wave=conf.getstr('config','wave_model')
    if not wave_flag or wave!='WW3':
        jlogger.info('WW3 is disabled.  This job need not be run.')
        return
    jlogger.info(hwrf_expt.conf.strinterp('config',
            '{stormlabel}: starting wave_post job for {out_prefix}'))
    hwrf_expt.ww3post.run()
    jlogger.info(hwrf_expt.conf.strinterp('config',
            '{stormlabel}: completed wave_post job for {out_prefix}'))

if __name__=='__main__':
    try:
        produtil.setup.setup()
        jlogger.info('wave_post is starting')
        main()
        jlogger.info('wave_post is completed')
    except Exception as e:
        jlogger.critical('wave_post is aborting: '+str(e),exc_info=True)
        sys.exit(2)

