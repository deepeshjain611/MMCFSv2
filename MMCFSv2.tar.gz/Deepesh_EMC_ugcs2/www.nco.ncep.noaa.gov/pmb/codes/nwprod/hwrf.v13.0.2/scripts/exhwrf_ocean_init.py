#! /usr/bin/env python

##@namespace scripts.exhwrf_ocean_init
# Runs the ocean initialization for the chosen ocean model and sets
# the ocean status file accordingly.  Does nothing if ocean is disabled
# via [config] run_ocean=no

import os, sys, traceback
import produtil.log, produtil.setup
import pom.exceptions
import hwrf.mpipomtc, hwrf.hycom, hwrf.coupling
import hwrf_alerts, hwrf.exceptions
from produtil.log import jlogger
from produtil.ecflow import set_ecflow_event

def main():
    """!Runs the ocean initialization and sets the ocean status file."""
    import hwrf_expt
    hwrf_expt.init_module()
    hwrf_expt.conf.add_fallback_callback(hwrf_alerts.fallback_callback)
    conf=hwrf_expt.conf
    ocean=conf.getstr('config','ocean_model')
    logger=conf.log('exhwrf_ocean_init')
    ocstatus=hwrf_expt.ocstatus
    ocstatus.unset(logger)
    try:
        fail=conf.getstr('failure','ocean_init','none')
        if fail=='unexpected_failure':
            raise hwrf.exceptions.UnexpectedFailureTest()
        if fail=='expected_failure':
            raise hwrf.exceptions.ExpectedFailureTest()

        if not conf.getbool('config','run_ocean'):
            jlogger.info('Ocean is disabled.  This job need not be run.')
            ocstatus.set(False,logger)
            return
        if ocean=='POM':
            hwrf_expt.pominit.run()
            ocstatus.set(True,logger)
            set_ecflow_event('Pom',logger)
        elif ocean=='HYCOM':
            hi=hwrf_expt.hycominit
            hi.run()
            hi.fill_ocstatus(ocstatus,logger)
            set_ecflow_event('Hycom',logger)
        else:
            jlogger.critical('Config file error: unsupported ocean model '
                             '%s.  Will run without ocean.'%(repr(ocean),))
            ocstatus.set(False,logger)
    except pom.exceptions.POMUnsupportedBasin as e:
        produtil.log.postmsg('Unsupported basin: will run without ocean.')
        ocstatus.set(False,logger)
        return
    except(SyntaxError,TypeError,ReferenceError,MemoryError,AttributeError,
           AssertionError,NameError,hwrf.exceptions.UnexpectedFailureTest,
           pom.exceptions.UnexpectedPOMFailureTest) as ne:
        logger.error('Could not run OCEAN init due to FATAL ERROR; aborting workflow: '+str(ne),exc_info=True)
        raise
    except Exception as e:
        msg='Could not run ocean init: will run without ocean.  Unhandled exception: '+str(e)
        if conf.fallback('ocean_init_failed',msg+
              '\n\nPython stack information at location of exception:\n\n'
              +traceback.format_exc()):
            logger.error(msg,exc_info=True)
            ocstatus.set(False,logger)
            return
        raise

if __name__=='__main__':
    try:
        produtil.setup.setup()
        main()
    except Exception as e:
        jlogger.critical('HWRF Ocean Initialization is aborting: '
                         +str(e),exc_info=True)
        sys.exit(2)
