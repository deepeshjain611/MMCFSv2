#! /usr/bin/env python

##@namespace scripts.exhwrf_ensda_relocate_pre
#Determines whether the ENSDA relocation needs to be run for this cycle and
#writes the ENSDA flag file.

import sys, os
import produtil.setup, produtil.log
from produtil.log import jlogger
from hwrf.ensda import unset_ensdastatus

def main():
    """!Based on the configuration, write an ensda flag file that will
    either request, or not request, the ensemble relocation jobs to run."""
    import hwrf_expt
    hwrf_expt.init_module(make_ensemble_da=True)

    conf=hwrf_expt.conf
    logger=conf.log('exhwrf_ensda_relocate_pre')
    flag_file=conf.getstr('ensda_relocate_pre','ens_rlct_flag_file')
    unset_ensdastatus(conf,flag_file,logger)
    run_ens_relocate=conf.getbool('config','run_ens_relocation')
    if not run_ens_relocate:
        jlogger.info('ENSDA relocation is disabled for this configuration.  '
                     'This job need not be run.')
        hwrf_expt.ensda_relocate_pre.write_flag_file(False)
        return
    hwrf_expt.ensda_relocate_pre.run()

if __name__=='__main__':
    try:
        produtil.setup.setup()
        jlogger.info('ensda_relocate_pre is starting')
        main()
        jlogger.info('ensda_relocate_pre is completed')
    except Exception as e:
        jlogger.critical('ensda_relocate_pre is aborting: '+str(e),exc_info=True)
        sys.exit(2)

