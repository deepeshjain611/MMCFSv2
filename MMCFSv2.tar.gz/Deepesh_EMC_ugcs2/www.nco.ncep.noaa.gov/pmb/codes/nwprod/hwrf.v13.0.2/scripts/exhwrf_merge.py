#! /usr/bin/env python

##@namespace scripts.exhwrf_merge
# Merges the exhwrf_relocate and exhwrf_gsi outputs to create the
# final input to the exhwrf_forecast.  
#
# @note This job should NOT be run if GSI is disabled.  When using
# relocated GFS or GEFS analysis as input to the forecast, the
# exhwrf_merge is superfluous and will harm the forecast.

import os, sys, produtil.log, produtil.setup
from produtil.log import jlogger
import hwrf.gsi

def fail(msg):
    """!Log a message to the produtil.log.jlogger and exit with status 2
    @param msg the error message """
    jlogger.error(msg)
    sys.exit(2)

def main():
    """!Run the hwrf.relocation.Merge."""
    ENV=os.environ
    ompnum=ENV['OMP_NUM_THREADS']
    pureomp=ENV['PURE_OPENMP_THREADS']
    if ompnum != pureomp:
        os.environ['OMP_NUM_THREADS']=pureomp
    init_model=ENV.get('INIT_MODEL','GDAS1').lower()
    if init_model!='gfs' and init_model!='gdas1':
        fail('Aborting: init_model="%s" must be "gfs" or "gdas1"'
             %(init_model,))
    
    import hwrf_expt
    hwrf_expt.init_module()
    conf=hwrf_expt.conf
    logger=conf.log('exhwrf_merge')
    allow_fallbacks=conf.getbool('config','allow_fallbacks',False)
    if init_model=='gfs':
        jlogger.info('MERGE does not need to be run for INIT_MODEL=GFS')
        hwrf_expt.gfs_merge.run()
    elif not hwrf_expt.conf.getbool('config','run_gsi'):
        jlogger.info('GSI is disabled via configuration settings.  '
                     'This job need not be run.')
        sys.exit(0)
    elif not hwrf.gsi.get_gsistatus(conf,'gsi_d02',logger) and \
         not hwrf.gsi.get_gsistatus(conf,'gsi_d03',logger):
        jlogger.info('GSI status file claims GSI is disabled for both '
                     'domains.  This job need not be run.')
        sys.exit(0)
    elif hwrf_expt.gsi_d02 is not None and \
         not hwrf.gsi.get_gsistatus(conf,'gsi_d02',logger) and \
         allow_fallbacks:
        jlogger.info('GSI failed for d02. Fallback is allowed. '
                     'This job need not be run.')
        sys.exit(0)
    elif hwrf_expt.gsi_d03 is not None and \
         not hwrf.gsi.get_gsistatus(conf,'gsi_d03',logger) and \
         allow_fallbacks:
        jlogger.info('GSI failed for d03. Fallback is allowed. '
                     'This job need not be run.')
        sys.exit(0)
    else:
        hwrf_expt.gdas_merge.run()

if __name__=='__main__':
    try:
        produtil.setup.setup()
        jlogger.info('exhwrf_merge is starting')
        main()
        jlogger.info('exhwrf_merge has completed')
    except Exception as e:
        jlogger.critical('HWRF merge is aborting: '+str(e),exc_info=True)
        sys.exit(2)
