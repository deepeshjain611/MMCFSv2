#! /usr/bin/env python

import os, sys, traceback
import produtil.log, produtil.setup
import hwrf.ww3, hwrf.coupling
import hwrf_alerts , hwrf.exceptions
from produtil.log import jlogger
from produtil.ecflow import set_ecflow_event

def main():
    import hwrf_expt
    hwrf_expt.init_module()
    hwrf_expt.conf.add_fallback_callback(hwrf_alerts.fallback_callback)
    conf=hwrf_expt.conf
    wave=conf.getstr('config','wave_model')
    logger=conf.log('exhwrf_wave_init')
    wvstatus=hwrf_expt.wvstatus
    wvstatus.unset(logger)
    try:
        fail=conf.getstr('failure','wave_init','none')
        if fail=='unexpected_failure':
            raise hwrf.exceptions.UnexpectedFailureTest()
        if fail=='expected_failure':
            raise hwrf.exceptions.ExpectedFailureTest()

        if not conf.getbool('config','run_wave'):
            jlogger.info('Wave is disabled.  This job need not be run.')
            wvstatus.set(False,logger)
            return
        if wave=='WW3':
            hwrf_expt.ww3init.run()
            wvstatus.set(True,logger)
            set_ecflow_event('Wave',logger)
        else:
            jlogger.critical('Config file error: unsupported wave model '
                             '%s.  Will run without wave.'%(repr(ocean),))
            wvstatus.set(False,logger)
    except(SyntaxError,TypeError,ReferenceError,MemoryError,AttributeError,
           AssertionError,NameError,hwrf.exceptions.UnexpectedFailureTest) as ne:
        logger.error('Could not run wave init due to FATAL ERROR; aborting workflow: '+str(ne),exc_info=True)
        raise
    except Exception as e:
        msg='Could not run wave init: will run without wave.  Unhandled exception: '+str(e)
        if conf.fallback('wave_init_failed',msg+
              '\n\nPython stack information at location of exception:\n\n'
              +traceback.format_exc()):
            logger.error(msg,exc_info=True)
            wvstatus.set(False,logger)
            return
        raise

if __name__=='__main__':
    try:
        produtil.setup.setup()
        jlogger.info('HWRF wave init starting.')
        main()
        jlogger.info('HWRF wave init completed.')
    except Exception as e:
        jlogger.critical('HWRF Wave Initialization is aborting: '
                         +str(e),exc_info=True)
        sys.exit(2)
