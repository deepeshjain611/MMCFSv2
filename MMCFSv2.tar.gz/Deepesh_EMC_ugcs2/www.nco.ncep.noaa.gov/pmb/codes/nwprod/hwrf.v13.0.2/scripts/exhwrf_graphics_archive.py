#! /usr/bin/env python

##@namespace scripts.exhwrf_wrfout_archive
# Archives graphics input files to tape via the "htar" command.
#
# To enable this script, you must set the wrfout option in the [archive]
# configuration section:
# @code[.conf]
# [archive]
# wrfout=hpss:/NCEPDEV/emc-hwrf/2year/Jane.Doe/wrfout/{out_prefix}.tar
# @endcode
#
# The extension must be .tar, and the only archiving method supported is
# hpss:/ (which uses htar)

import os, sys, glob
import produtil.setup, produtil.log, produtil.run, produtil.cd
import hwrf.config, hwrf.numerics

from produtil.log import jlogger
from produtil.run import batchexe, checkrun, run

def main():
    CONFhwrf=os.environ['CONFhwrf']
    conf=hwrf.config.from_file(CONFhwrf)
    ymdh=conf.getstr('config','cycle')
    conf.cycle=hwrf.numerics.to_datetime(ymdh)

    logger=conf.log('graphics_archive')

    com=conf.getstr('dir','com')
    basin1lc=conf.getstr('config','basin1lc')
    stnum=conf.getint('config','stnum')
    vitglob='%s/*%02d%c.%10s.storm_vit'%(com,stnum,basin1lc,ymdh)
    vitfile=None
    glib=glob.glob(vitglob)
    logger.info('globbed: %s'%(repr(glib),))
    for gfile in glib:
        vitfile=gfile
        with open(vitfile,'rt') as vf:
            vits=hwrf.storminfo.parse_tcvitals(vf,logger=logger,raise_all=True)
        logger.info('%s: read in: %s'%(vitfile,repr(vits)))
        if vits:
            conf.syndat=vits[-1]
            logger.info('vitals: '+conf.syndat.as_tcvitals());
            break
        else:
            logger.warning('%s: no vitals data in this file'%(vitfile,))

    if not conf.syndat:
        logger.error('%s: no vitals data found'%(vitglob,))
        sys.exit(1)

    thearchive=conf.timestrinterp('archive','{graphics}',0)
    if not thearchive:
        jlogger.info('No graphics option in [archive] section.  Will '
                     'not make graphics archive.')
        sys.exit(0)

    workdir=conf.strinterp('config','{WORKhwrf}/graphics-archive')
    comdir=conf.getdir('com')
    hsi_path=conf.getexe('hsi')
    htar_path=conf.getexe('htar')

    archive(comdir,logger,thearchive,hsi_path,htar_path)

def archive(comdir,logger,archfile,hsi_path,htar_path):
    archme=set()
    search_str=[ 
        'ww3.grb2', 'ww3_ounf.nc', 'ww3_outp_bull.tar', 'ww3_outp_spec.tar',
        'hwrfprs.d1.0p20','hwrfprs.d2.0p06', 'hwrfprs.d3.0p02',
        'hwrfsat.d1.0p20', 'hwrfsat.d2.0p06', 'hwrfsat.d3.0p02',
        'swath.ctl','swath.dat','wind10.ascii','stats.short',
        'wrfdiag_d02','wrfdiag_d03','holdvars.txt','trak.','atcf','htcf',
        'domain.center', '0p25', '.pom.', 'wind10m.ascii' ]
    with produtil.cd.NamedDir(comdir,logger=logger):
        comlist=os.listdir('.')
        for comf in comlist:
            for ss in search_str:
                if comf.find(ss)>=0:
                    archme.add('./'+comf)
                    break

        if not archme:
            logger.error('%s: no files to archive!'%(comdir,))
            sys.exit(1)

        if archfile[0:5]!='hpss:':
            logger.error('The graphics archive path must begin with "hpss:": '+
                         archfile)
            sys.exit(1)
        archfile=archfile[5:]
        adir=os.path.dirname(archfile)
        mkdir=batchexe(hsi_path)['-P','mkdir','-p',adir]
        run(mkdir,logger=logger)
        cmd=batchexe(htar_path)['-vcpf',archfile][archme]
        checkrun(cmd,logger=logger)

if __name__=='__main__':
    try:
        produtil.setup.setup()
        jlogger.info("HWRF graphics_archive job starting")
        main()
        jlogger.info("HWRF graphics_archive job completed")
    except Exception as e:
        jlogger.critical('HWRF graphics archive is aborting: '+str(e),
                         exc_info=True)
        sys.exit(2)
