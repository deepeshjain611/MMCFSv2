#! /usr/bin/env python

"""This script runs the ocean post processor when ocean_model==HYCOM"""

import sys, os
import produtil.setup, produtil.log
from produtil.log import jlogger

def main():
    ENV=os.environ
    ompnum=ENV['OMP_NUM_THREADS']
    pureomp=ENV['PURE_OPENMP_THREADS']
    if ompnum != pureomp:
        os.environ['OMP_NUM_THREADS']=pureomp
    import hwrf_expt
    hwrf_expt.init_module(make_ensemble_da=False)

    conf=hwrf_expt.conf
    ocean_flag=conf.getbool('config','run_ocean')
    ocean=conf.getstr('config','ocean_model')
    if not ocean_flag or ocean!='HYCOM':
        jlogger.info('HYCOM is disabled.  This job need not be run.')
        return
    hwrf_expt.hycompost.run()

if __name__=='__main__':
    try:
        produtil.setup.setup()
        jlogger.info('ocean_post is starting')
        main()
        jlogger.info('ocean_post is completed')
    except Exception as e:
        jlogger.critical('ocean_post is aborting: '+str(e),exc_info=True)
        sys.exit(2)

