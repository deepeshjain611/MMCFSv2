#! /usr/bin/env python

##@namespace scripts.exhwrf_hycomab_archive
# Archives *.a and *.b files output by the hycom component of the 
# coupled HWRF forecast job.
#
# This Python script will archive all *archv*.[ab] files found in the
# run directory of the forecast job, found via the
# hwrf_expt.runwrf.location.  It is controlled by the [archive]
# section hycomab option, which must be set to an archive path of this
# syntax:
#
# @code
# [archive]
# hycomab=hpss:/NCEPDEV/2year/emc-marine/{ENV[USER]}/{SUBEXPT}/hycomab/{out_prefix}.tar
# @endcode
#
# The hycomab option, if present, will be expanded to get the path to
# the target archive location.  The archive is then created with HTAR,
# sending the files that matched the *archv*.[ab] glob.

import os, sys, glob
import produtil.setup, produtil.log, produtil.run, produtil.cd
import hwrf.numerics
import hwrf_expt

from produtil.log import jlogger
from produtil.run import exe, checkrun, run, batchexe

def main():
    hwrf_expt.init_module()
    conf=hwrf_expt.conf
    if not conf.has_option('archive','hycomab'):
        jlogger.info('No hycomab option in [archive] section.  '
                     'Will not make hycomab archive.')
        sys.exit(0)

    logger=conf.log()
    rundir=hwrf_expt.runwrf.location
    abfiles=list()
    with produtil.cd.NamedDir(rundir):
        for globme in [ "*archv*.[ab]" ]:
            globout=list(glob.glob(globme))
            if not globout:
                logger.warning('There are no files matching %s in %s'%(
                        globme, rundir))
            abfiles.extend(globout)
        if not abfiles:
            # Send an error at critical level so it ends up in the jlogfile
            logger.critical('Could not find any hycom output files.  '
                            'Hycom failed.  Will now cry.')
            sys.exit(1)

        # List the files to archive at info level (stdout):
        logger.info('Found %d hycom files:\n    %s'%(
                len(abfiles),"\n    ".join(abfiles)))

        thearchive=conf.timestrinterp('archive','{hycomab}',0)
        if thearchive[0:5]!='hpss:':
            logger.error('The hycomab archive path must begin with "hpss:": '+
                         thearchive)
            sys.exit(1)
        thearchive=thearchive[5:]
        adir=os.path.dirname(thearchive)

        # Send a message directly to the jlogfile about the archiving:
        jlogger.info('%s: archiving %d hycom files to HPSS.'
                     %(thearchive,len(abfiles)))

        mkdir=batchexe(conf.getexe('hsi'))['-P','mkdir','-p',adir]
        run(mkdir,logger=logger)
        cmd=batchexe(conf.getexe('htar'))['-vcpf',thearchive][abfiles]
        checkrun(cmd,logger=logger)

if __name__=='__main__':
    try:
        produtil.setup.setup()
        jlogger.info("HWRF hycomab archive job starting")
        main()
        jlogger.info("HWRF hycomab archive job completed")
    except Exception as e:
        jlogger.critical('HWRF hycomab archive is aborting: '+str(e),
                         exc_info=True)
        sys.exit(2)
