#!/bin/sh
###################################################################
echo "----------------------------------------------------"
echo "exnawips - convert NCEP GRIB files into GEMPAK Grids"
echo "----------------------------------------------------"
# History: Mar 2000 - First implementation of this new script.
# S Lilly: May 2008 - Add logic to make sure that all of the
#                     data produced from the restricted ECMWF
#                     data on the CCS is properly protected.
# Simon H: May 2014 - Update to create the HWRF and GFDL gempak
#                     files from grib2 files, $1 is GRIB file name
#                     $2 is the directory name
# Kit M:   Jun 2016 - Migration to Cray XC40 and use of cfp for MPMD.
#####################################################################
set -x

postmsg "$jlogfile" "Starting $0"

mkdir -p $DATA/hwrf $DATA/hwrfp $DATA/logs

# Use a custom table to decode reflectivity parameters in core and global files
ln -s ${PARMhwrf}/g2varsncep1.tbl $DATA/hwrf/g2varsncep1.tbl

# Use custom tables to filter some parameters from synoptic files
ln -s ${PARMhwrf}/g2varsncep1_synoptic.tbl $DATA/hwrfp/g2varsncep1.tbl
ln -s ${PARMhwrf}/g2varswmo2_synoptic.tbl $DATA/hwrfp/g2varswmo2.tbl

export fstart=0
export finc=6
export fend=126

export MODEL=$DATA # Used for datatype.tbl in meta tasks
rm -f poescript.gempak

# HWRF-specific grids
for GRID_TYPE in "synoptic.0p125" "core.0p015" "global.0p25"; do
  for fhr in $(seq -f'%03g' ${fstart:?} ${finc:?} ${fend:?}); do
    echo "${USHhwrf:?}/hwrf_gempak.sh $GRID_TYPE $fhr &> $DATA/logs/$GRID_TYPE.f$fhr.out" >> poescript.gempak
  done
done

# Gempak meta tasks
echo "${USHhwrf}/hwrf_gempak_meta_grid.sh &> $DATA/logs/meta_grid.out" >> poescript.gempak
echo "${USHhwrf}/hwrf_gempak_meta_nest.sh &> $DATA/logs/meta_nest.out" >> poescript.gempak

aprun -N $PTILE -n $((NODES*$PTILE)) cfp poescript.gempak
export err=$?; err_chk

postmsg "$jlogfile" "$0 completed normally"

