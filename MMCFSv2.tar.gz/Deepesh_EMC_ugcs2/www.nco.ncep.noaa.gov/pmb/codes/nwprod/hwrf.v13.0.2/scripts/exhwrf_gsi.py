#! /usr/bin/env python

##@namespace scripts.exhwrf_gsi
#Runs the GSI data assimilation system scripts in hwrf.gsi on one
#of the HWRF resolutions.  The resolution is selected by the
#$GSI_DOMAIN environment variable:
#
#* $GSI_DOMAIN=d02 --- run the intermediate resolution GSI
#* $GSI_DOMAIN=d03 --- run the innermost domain GSI

## List of symbols exported by "from exhwrf_gsi import *"
__all__=[]
import logging, traceback
import os, sys, produtil.log, produtil.setup, produtil.cluster
from produtil.ecflow import set_ecflow_event
from produtil.log import jlogger
import hwrf_wcoss, hwrf_alerts
import hwrf.gsi, hwrf.exceptions

def fail(msg):
    """!Logs a message to the produtil.log.jlogger and exits with status 2
    @param msg the error message"""
    jlogger.error(msg)
    sys.exit(2)

def main():
    """!Runs the selected GSI task."""
    ENV=os.environ
    gsi_domain=ENV['GSI_DOMAIN'].lower()
    if gsi_domain!='d02' and gsi_domain!='d03':
        fail('Aborting: gsi_domain="%s" must be "d02" or "d03"'%(gsi_domain,))
    
    import hwrf_expt
    hwrf_expt.init_module()
    hwrf_expt.conf.add_fallback_callback(hwrf_alerts.fallback_callback)
    conf=hwrf_expt.conf
    logger=conf.log('exhwrf_gsi')

    if not conf.getbool('config','run_gsi'):
        jlogger.info('GSI is disabled.  This job need not be run.')
        sys.exit(0)

    try:
        fail=conf.getstr('failure','gsi_'+gsi_domain,'none')
        if fail=='unexpected_failure':
            raise hwrf.exceptions.UnexpectedFailureTest()
        if fail=='expected_failure':
            raise hwrf.exceptions.ExpectedFailureTest()

        if produtil.cluster.name() in ['gyre','tide']:
            hwrf_wcoss.set_vars_for_gsi(logger)
        else:
            logger.info('Not on WCOSS phase 2, so not setting WCOSS-specific vars.')

        if not hwrf.gsi.get_gsistatus(conf,'gsi_'+gsi_domain,logger):
            jlogger.info('GSI is disabled for %s.  This job need not be run.'
                         %(gsi_domain,))
            sys.exit(0)
        else:
            logger.info('GSI is enabled for %s.'%(gsi_domain,))

        if gsi_domain=='d02':
            hwrf_expt.gsi_d02.run()
        else:
            hwrf_expt.gsi_d03.run()
    except(SyntaxError,TypeError,ReferenceError,MemoryError,AttributeError,
           AssertionError,NameError,hwrf.exceptions.UnexpectedFailureTest) as ne:
        logger.error('HWRF GSI is aborting due to FATAL ERROR: '+str(ne),exc_info=True)
        sys.exit(2)
    except Exception as e:
        msg='Could not run gsi for domain %s; will use relocate_gfs vortex.  Unhandled exception: %s'%(gsi_domain,str(e))
        if conf.fallback('gsi_'+gsi_domain+'_failed',msg+
              '\n\nPython stack information at location of exception:\n\n'
              +traceback.format_exc()):
            hwrf.gsi.reset_gsistatus(conf,'gsi_'+gsi_domain,logger)
            logger.error(msg,exc_info=True)
            set_ecflow_event('canceled',logger)
            return
        raise

if __name__=='__main__':
    try:
        produtil.setup.setup(thread_logger=True,eloglevel=logging.INFO)
        main()
    except Exception as e:
        jlogger.critical('HWRF GSI is aborting: '+str(e),exc_info=True)
        sys.exit(2)
