#! /usr/bin/env python

##@namespace scripts.exhwrf_meanhx
#Calculate Hx of ensemble mean for EnKF
#

import logging
import os, sys, produtil.log, produtil.setup, produtil.cluster
from produtil.log import jlogger
import hwrf_wcoss

def fail(msg):
    """!Logs a message to the produtil.log.jlogger and exits with status 2
    @param msg the error message"""
    jlogger.error(msg)
    sys.exit(2)

def main():
    """!Run the meanhx task."""

    import hwrf_expt
    hwrf_expt.init_module()
    if not hwrf_expt.conf.getbool('config','run_ensemble_da',False):
        jlogger.info('meanhx is disabled.  This job need not be run.')
        sys.exit(0)

    hwrf_expt.init_module()
    logger=hwrf_expt.conf.log('exhwrf_meanhx')

    if produtil.cluster.name() in ['gyre','tide']:
        hwrf_wcoss.set_vars_for_gsi(logger)
    else:
        logger.info('Not on WCOSS, so not setting WCOSS-specific vars.')

    hwrf_expt.gsi_meanhx.run()

if __name__=='__main__':
    try:
        produtil.setup.setup()
        main()
    except Exception as e:
        jlogger.critical('HWRF meanhx is aborting: '+str(e),exc_info=True)
        sys.exit(2)
