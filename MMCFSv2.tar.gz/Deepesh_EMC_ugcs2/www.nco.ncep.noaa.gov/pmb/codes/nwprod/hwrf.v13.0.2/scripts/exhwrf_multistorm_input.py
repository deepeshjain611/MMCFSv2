#! /usr/bin/env python

import logging, os, sys
import produtil.log, produtil.setup, produtil.run, produtil.fileop
from produtil.log import jlogger
from produtil.run import exe
import hwrf.input

def main():
    import hwrf_expt
    hwrf_expt.init_module(make_ensemble_da=True)
    hwrf_expt.multistormin.run()

if __name__=='__main__':
    try:
        produtil.setup.setup(thread_logger=True,eloglevel=logging.INFO)
        jlogger.info("HWRF multistorm input copier job starting")
        main()
        jlogger.info("HWRF multistorm input copier job completed")
    except Exception as e:
        jlogger.critical('HWRF input is aborting: '+str(e),exc_info=True)
        sys.exit(2)
