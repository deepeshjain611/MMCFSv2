#! /usr/bin/env python

##@namespace scripts.exhwrf_gsi_post
#Runs the HWRF post-processing on the inputs and outputs to the
#GSI.  This includes:
#  1. ORG --- the original parent model data, interpolated to the HWRF grid,
#  2. GES --- the first guess: the input to GSI
#  3. ANL --- the final output of the data assimilation
#
#Intermediate output files are post-processed and interpolated to
#latitude-longitude grids.  The implementation of this is in the
#hwrf.gsipost and hwrf.hwrfsystem modules.

import os, sys
import produtil.setup, produtil.log, produtil.cd
import hwrf_expt
from produtil.log import jlogger
import hwrf.gsi

def main():
    """!Runs the HWRF post-processing described in the exhwrf_gsi_post
    module description."""
    hwrf_expt.init_module()
    logger=hwrf_expt.conf.log('exhwrf_gsi_post')
    allow_fallbacks=hwrf_expt.conf.getbool('config','allow_fallbacks',False)
    if not hwrf_expt.conf.getbool('config','run_gsi'):
        jlogger.info('GSI is disabled.  This job need not be run.')
        sys.exit(0)

    if hwrf_expt.gsi_d02 is not None and \
       not hwrf.gsi.get_gsistatus(hwrf_expt.conf,'gsi_d02',logger) and \
       allow_fallbacks:
        jlogger.info('GSI failed or was aborted for d02.  This job need not be run.')
        sys.exit(0)

    if hwrf_expt.gsi_d03 is not None and \
       not hwrf.gsi.get_gsistatus(hwrf_expt.conf,'gsi_d03',logger) and \
       allow_fallbacks:
        jlogger.info('GSI failed or was aborted for d03.  This job need not be run.')
        sys.exit(0)

    produtil.fileop.chdir(hwrf_expt.conf.getdir('WORKhwrf'),logger=logger)

    logger.info('Unrun GSI post and gribber')
    hwrf_expt.gsipost.unrun()
    hwrf_expt.gsigribber.unrun()

    logger.info('Run GSI post')
    hwrf_expt.gsipost.run()

    logger.info('Run GSI gribber, and deliver to com.')
    hwrf_expt.gsigribber.run(now=True)

if __name__=='__main__':
    try:
        produtil.setup.setup()
        jlogger.info("HWRF GSI post job starting")
        main()
        jlogger.info("HWRF GSI post job completed")
    except Exception as e:
        jlogger.critical('HWRF GSI post is aborting: '+str(e),
                         exc_info=True)
        sys.exit(2)
