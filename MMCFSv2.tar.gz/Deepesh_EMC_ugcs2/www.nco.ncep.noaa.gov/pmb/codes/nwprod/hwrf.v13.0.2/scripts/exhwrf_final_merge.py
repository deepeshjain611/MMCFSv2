#! /usr/bin/env python

import logging, os, sys, produtil.log, produtil.setup
from produtil.log import jlogger

def fail(msg):
    jlogger.error(msg)
    sys.exit(2)

def main():

    jlogger.info('HWRF Final Merge is starting.')
    import hwrf_expt
    hwrf_expt.init_module()
    conf=hwrf_expt.conf
    logger=hwrf_expt.conf.log('exhwrf_final_merge')

    # Some Basic Checks before we run final merge ....
    run_multistorm=conf.getbool('config','run_multistorm',False)
    fakestormid=conf.getstr('config','fakestormid','nofakeid')
    stormid=conf.getstr('config','STID','nostid')
    multistorm_sids=conf.getstr('config','multistorm_sids','nosids')

    if not run_multistorm:
        fail("CAN NOT Run Final Merge. Set 'run_multistorm=yes' in" + \
             " hwrf_basic.conf and then run launcher task.")
    elif stormid=='nostid':
        logger.error("ERROR: Final Merge no 'STID' defined.")
        sys.exit(1)
    elif fakestormid=='nofakeid':
        logger.error("ERROR: Final Merge no 'fakestormid' defined in conf file.")
        sys.exit(1)
    # Plans are to run multistorm with 0 or 1 storms ...
    # in the future. So pull this check when appropriate.
    elif multistorm_sids=='nosids':
        logger.error("ERROR: Final Merge no 'multistorm_sids' defined in conf file.")
        sys.exit(1)
    elif not fakestormid.upper() ==  stormid.upper():
        logger.error("ERROR: Final merge can only run on "
                     "your defined 'fakestormid': %s. This is "
                     "'STID' %s"%(fakestormid, stormid))
        sys.exit(1)
    else:
        jlogger.info('Basic Final Merge Checks passed. Proceed with Running Final Merge.')

    hwrf_expt.finalmerge.run()

    jlogger.info('Final Merge has completed.')


if __name__=='__main__':
    try:
        produtil.setup.setup()
        main()
    except Exception as e:
        jlogger.critical('HWRF final merge is aborting: '+str(e),exc_info=True)
        sys.exit(2)
