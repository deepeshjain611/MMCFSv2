#!/bin/ksh
set -x

curdir=`pwd`

echo "---- This ONLY builds GSM and NEMS-----"
echo "---- MOM5 and CICE needs to be added --"
echo "- exiting, remove exit to use this script"
#exit 0

# To build using the appbuilder, run this from the command line:
# NEMS/NEMSAppbuilder rebuild app=UGCS

##. /usrx/local/Modules/default/init/ksh

      ROOTDIR=$curdir
      MACHINE_ID=wcoss

      # CICE
      CICE_SRCDIR=$ROOTDIR/CICE
      CICE_BINDIR=$ROOTDIR/CICE-INSTALL

      # MOM5
      MOM6_SRCDIR=$ROOTDIR/MOM6
      MOM6_BINDIR=$ROOTDIR/MOM6-INSTALL
      
      source $ROOTDIR/setup.xc.intel
      cd $ROOTDIR/NEMS/src

      # Setup configuration for NEMS and modules used for NEMS and GSM
      #
      ./configure coupled_intel_wcoss
      # copy_diff_files ../../conf/configure.nems.Wcoss.intel conf/configure.nems
      #module purge
      module use $ROOTDIR/NEMS/src/conf
      #module load modules.nems
      #module list

      # Build CICE
      
      # Need to add

      # Build MOM5
###################################################################################



#####################################################################################################
      # Need to add

      # Build GSM
      export COMP=GSM
      export COMP_SRCDIR=$ROOTDIR/GSM
      export GSM_DIR=$ROOTDIR/GSM
      export COMP_BINDIR=$ROOTDIR/GSM-INSTALL
      mkdir -p $COMP_BINDIR
      cd $COMP_SRCDIR
      ./configure gsm_intel_$MACHINE_ID
      make GSM_DIR=$COMP_SRCDIR nuopcdistclean
      GSM_BUILDOPT="GOCART_MODE=stub"
      make GSM_DIR=$COMP_SRCDIR $GSM_BUILDOPT DESTDIR= INSTDIR=$COMP_BINDIR nuopcinstall

      # Build NEMS
      cd $ROOTDIR/NEMS/src
      #make nems COMP=,gsm, GSM_DIR=$GSM_BINDIR
      make nems COMP=,fv3,cice,mom6, GSM_DIR=$COMP_BINDIR CICE_DIR=$CICE_BINDIR MOM6_DIR=$MOM6_BINDIR  > log

      # Build the mppncombine executables for OCN output
      cd $ROOTDIR/sorc
      ./make.wcoss
