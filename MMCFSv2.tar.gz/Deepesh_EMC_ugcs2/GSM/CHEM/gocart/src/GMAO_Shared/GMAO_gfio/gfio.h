
        integer     NFILES_MAX
        parameter ( NFILES_MAX = 64 )

        integer     NVARS_MAX
        parameter ( NVARS_MAX = 128 )

        integer  MAXCHR
        parameter ( MAXCHR = 256 )
  
        integer PACK_BITS
        parameter ( PACK_BITS = 32766 )
 
        integer PACK_FILL
        parameter ( PACK_FILL = 32767 )
