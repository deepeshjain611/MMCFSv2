! -*-f90-*-

#ifdef _FILE_VERSION
  character(len=*), parameter :: version = _FILE_VERSION
#else
  character(len=*), parameter :: version = 'unknown'
#endif
