.. _Pages:

=====
Pages
=====

.. autodoxysummary::
   :toctree: generated/pages
   :generate:
   :kind: page

.. toctree::
   :glob:
   :maxdepth: 1

   generated/pages/*
