.. _API_Reference:

API Reference
=============

This API reference is a partial image of the complete API documentation.
The pages you find here are linkable - the url for the page is static.
The complete API documentation is generated with doxygen and can be found at http://noaa-gfdl.github.io/MOM6/APIs/.

.. toctree::
  :maxdepth: 1

  api/modules
