Working with MOM6
=================

.. toctree::
    :maxdepth: 1

    code_organization
    api/generated/pages/Runtime_parameter_system.rst
    api/generated/pages/Diagnostics.rst
    api/generated/pages/Horizontal_indexing.rst
    api/generated/pages/Advection.rst

