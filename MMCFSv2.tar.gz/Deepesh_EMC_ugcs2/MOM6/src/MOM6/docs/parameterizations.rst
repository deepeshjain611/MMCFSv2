Parameterizations
=================

Sub-grid scale parameterizations are broadly grouped into vertical and lateral directions, referring to the direction in which fluxes are predominantly oriented.

.. toctree::
  :maxdepth: 1

  parameterizations_vertical
  parameterizations_lateral
